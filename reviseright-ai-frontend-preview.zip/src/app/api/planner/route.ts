import { NextRequest, NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { students, studySessions } from "@/db/schema";
import { rebuildUnfinishedPlan } from "@/lib/server-planner";

export const runtime = "nodejs";

export async function POST(request: NextRequest) {
  try {
    const body = (await request.json()) as { hours?: unknown; action?: unknown };
    let updatedHours: number | null = null;

    if (body.hours !== undefined) {
      const parsedHours = Number(body.hours);
      if (!Number.isInteger(parsedHours) || parsedHours < 1 || parsedHours > 8) {
        return NextResponse.json({ error: "Daily study time must be between 1 and 8 whole hours." }, { status: 400 });
      }
      await db.update(students).set({ dailyStudyHours: parsedHours }).where(eq(students.id, 1));
      updatedHours = parsedHours;
    }

    const rebuiltCount = await rebuildUnfinishedPlan(1);
    const sessions = await db
      .select()
      .from(studySessions)
      .where(eq(studySessions.studentId, 1));

    return NextResponse.json({
      sessions,
      rebuiltCount,
      hours: updatedHours,
      message: updatedHours === null ? "Your unfinished sessions have been reorganized." : `Your unfinished sessions have been reorganized for ${updatedHours} hour${updatedHours === 1 ? "" : "s"} a day.`,
    });
  } catch (error) {
    console.error("Study plan rebuild failed:", error);
    return NextResponse.json({ error: "The timetable could not be rebuilt. Try again in a moment." }, { status: 500 });
  }
}

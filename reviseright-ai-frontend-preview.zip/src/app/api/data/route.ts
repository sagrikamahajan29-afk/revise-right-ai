import { NextResponse } from "next/server";
import { and, asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { quizAttempts, students, studySessions, topics } from "@/db/schema";
import { topicSeeds } from "@/lib/catalog";
import { buildStudyPlan, planWindowLength } from "@/lib/planner";

export const runtime = "nodejs";

function dateAfterToday(days: number): string {
  const date = new Date();
  date.setUTCHours(12, 0, 0, 0);
  date.setUTCDate(date.getUTCDate() + days);
  return date.toISOString().slice(0, 10);
}

function today(): string {
  return new Date().toISOString().slice(0, 10);
}

async function readProfile() {
  const [student] = await db.select().from(students).where(eq(students.id, 1)).limit(1);
  if (!student) return null;

  const studentTopics = await db
    .select()
    .from(topics)
    .where(eq(topics.studentId, student.id))
    .orderBy(asc(topics.position), asc(topics.id));
  const attempts = await db
    .select()
    .from(quizAttempts)
    .where(eq(quizAttempts.studentId, student.id))
    .orderBy(asc(quizAttempts.createdAt));
  const sessions = await db
    .select()
    .from(studySessions)
    .where(eq(studySessions.studentId, student.id))
    .orderBy(asc(studySessions.scheduledDate), asc(studySessions.startTime));

  return { student, topics: studentTopics, attempts, sessions };
}

export async function GET() {
  try {
    await db
      .insert(students)
      .values({
        id: 1,
        name: "Student",
        subject: "Operating Systems",
        examDate: dateAfterToday(30),
        dailyStudyHours: 2,
        studyPreference: "balanced",
      })
      .onConflictDoNothing();

    const [student] = await db.select().from(students).where(eq(students.id, 1)).limit(1);
    if (!student) {
      return NextResponse.json({ error: "Could not initialize the student profile." }, { status: 500 });
    }

    const currentTopics = await db.select({ name: topics.name }).from(topics).where(eq(topics.studentId, student.id));
    const existingNames = new Set(currentTopics.map((topic) => topic.name.toLowerCase()));
    for (const seed of topicSeeds) {
      if (existingNames.has(seed.name.toLowerCase())) continue;
      await db
        .insert(topics)
        .values({ studentId: student.id, ...seed })
        .onConflictDoNothing();
    }

    const currentSessions = await db
      .select({ id: studySessions.id })
      .from(studySessions)
      .where(and(eq(studySessions.studentId, student.id), eq(studySessions.status, "planned")))
      .limit(1);
    const allSessions = await db.select().from(studySessions).where(eq(studySessions.studentId, student.id));

    if (currentSessions.length === 0 && allSessions.length === 0) {
      const currentData = await readProfile();
      if (currentData) {
        const plan = buildStudyPlan(
          currentData.student,
          currentData.topics,
          currentData.attempts,
          currentData.sessions,
          today(),
          planWindowLength(currentData.student.examDate, today(), 7),
        );
        if (plan.length > 0) {
          await db.insert(studySessions).values(plan.map((session) => ({ ...session, studentId: student.id })));
        }
      }
    }

    const data = await readProfile();
    return NextResponse.json(data);
  } catch (error) {
    console.error("ReviseRight data load failed:", error);
    return NextResponse.json({ error: "Could not load the revision workspace. Check the database connection and try again." }, { status: 500 });
  }
}

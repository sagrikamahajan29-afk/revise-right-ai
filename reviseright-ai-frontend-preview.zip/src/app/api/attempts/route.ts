import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { quizAttempts } from "@/db/schema";
import { quizBank } from "@/lib/quiz-bank";

export const runtime = "nodejs";

const confidenceLevels = new Set(["Low", "Medium", "High"]);

export async function POST(request: NextRequest) {
  try {
    const body = (await request.json()) as {
      questionId?: unknown;
      answerIndex?: unknown;
      confidence?: unknown;
      assessmentId?: unknown;
    };
    const questionId = typeof body.questionId === "string" ? body.questionId : "";
    const assessmentId = typeof body.assessmentId === "string" ? body.assessmentId.trim().slice(0, 40) : "";
    const answerIndex = typeof body.answerIndex === "number" ? body.answerIndex : -1;
    const confidence = typeof body.confidence === "string" ? body.confidence : "";
    const question = quizBank.find((item) => item.id === questionId);

    if (!assessmentId) {
      return NextResponse.json({ error: "Start a quiz before submitting an answer." }, { status: 400 });
    }
    if (!question || !Number.isInteger(answerIndex) || answerIndex < 0 || answerIndex >= question.options.length) {
      return NextResponse.json({ error: "That answer could not be checked. Start the question again." }, { status: 400 });
    }
    if (!confidenceLevels.has(confidence)) {
      return NextResponse.json({ error: "Choose a confidence rating before checking your answer." }, { status: 400 });
    }

    const correct = answerIndex === question.answerIndex;
    const [attempt] = await db
      .insert(quizAttempts)
      .values({
        studentId: 1,
        topicName: question.topicName,
        questionId: question.id,
        assessmentId,
        answerIndex,
        correct,
        confidence,
      })
      .returning();

    return NextResponse.json({
      attempt,
      correct,
      correctIndex: question.answerIndex,
      explanation: question.explanation,
      correctAnswer: question.options[question.answerIndex],
    });
  } catch (error) {
    console.error("Quiz answer save failed:", error);
    return NextResponse.json({ error: "The answer could not be saved. Check the database connection and try again." }, { status: 500 });
  }
}

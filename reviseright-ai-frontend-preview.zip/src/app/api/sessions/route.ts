import { NextRequest, NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { studySessions } from "@/db/schema";

export const runtime = "nodejs";

export async function PATCH(request: NextRequest) {
  try {
    const body = (await request.json()) as { sessionId?: unknown; status?: unknown };
    const sessionId = typeof body.sessionId === "number" ? body.sessionId : Number(body.sessionId);
    const status = body.status === "completed" ? "completed" : body.status === "planned" ? "planned" : "";

    if (!Number.isInteger(sessionId) || sessionId < 1 || !status) {
      return NextResponse.json({ error: "Choose a valid study session and status." }, { status: 400 });
    }

    const updated = await db
      .update(studySessions)
      .set({ status })
      .where(and(eq(studySessions.id, sessionId), eq(studySessions.studentId, 1)))
      .returning();

    if (updated.length === 0) {
      return NextResponse.json({ error: "That study session was not found." }, { status: 404 });
    }

    return NextResponse.json({ session: updated[0] });
  } catch (error) {
    console.error("Study session update failed:", error);
    return NextResponse.json({ error: "The study session could not be updated." }, { status: 500 });
  }
}

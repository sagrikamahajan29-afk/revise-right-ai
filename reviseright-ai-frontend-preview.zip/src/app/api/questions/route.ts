import { NextRequest, NextResponse } from "next/server";
import { quizBank } from "@/lib/quiz-bank";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const requestedTopic = request.nextUrl.searchParams.get("topic") ?? "all";
  let selected = quizBank.filter((question) => requestedTopic === "all" || question.topicName === requestedTopic);

  if (requestedTopic === "all") {
    const topicNames = [...new Set(quizBank.map((question) => question.topicName))];
    selected = topicNames
      .map((topicName) => {
        const topicQuestions = quizBank.filter((question) => question.topicName === topicName);
        return topicQuestions[Math.floor(Math.random() * topicQuestions.length)];
      })
      .filter(Boolean);
  } else {
    selected = [...selected].sort(() => Math.random() - 0.5);
  }

  return NextResponse.json({
    questions: selected.map((question) => ({
      id: question.id,
      topicName: question.topicName,
      prompt: question.prompt,
      options: question.options,
      difficulty: question.difficulty,
    })),
    message:
      selected.length === 0
        ? "There are no built-in diagnostic questions for this custom topic yet. Use a focused practice session, or continue with an Operating Systems topic."
        : null,
  });
}

import { NextRequest, NextResponse } from "next/server";
import { and, asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { students, topics } from "@/db/schema";
import { rebuildUnfinishedPlan } from "@/lib/server-planner";

export const runtime = "nodejs";

const difficultyValues = new Set(["Easy", "Medium", "Hard"]);
const preferenceValues = new Set(["balanced", "reading", "video", "practice"]);

function isIsoDate(value: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const date = new Date(`${value}T12:00:00.000Z`);
  return Number.isFinite(date.getTime()) && date.toISOString().slice(0, 10) === value;
}

export async function PATCH(request: NextRequest) {
  try {
    const body = (await request.json()) as Record<string, unknown>;
    let changed = false;
    const studentChanges: {
      name?: string;
      subject?: string;
      examDate?: string;
      dailyStudyHours?: number;
      studyPreference?: string;
    } = {};

    if (body.name !== undefined) {
      const value = typeof body.name === "string" ? body.name.trim() : "";
      if (!value || value.length > 100) return NextResponse.json({ error: "Enter a name up to 100 characters." }, { status: 400 });
      studentChanges.name = value;
    }
    if (body.subject !== undefined) {
      const value = typeof body.subject === "string" ? body.subject.trim() : "";
      if (!value || value.length > 120) return NextResponse.json({ error: "Enter a subject up to 120 characters." }, { status: 400 });
      studentChanges.subject = value;
    }
    if (body.examDate !== undefined) {
      const value = typeof body.examDate === "string" ? body.examDate : "";
      if (!isIsoDate(value)) return NextResponse.json({ error: "Choose a valid exam date." }, { status: 400 });
      studentChanges.examDate = value;
    }
    if (body.dailyStudyHours !== undefined) {
      const value = Number(body.dailyStudyHours);
      if (!Number.isInteger(value) || value < 1 || value > 8) {
        return NextResponse.json({ error: "Daily study time must be between 1 and 8 whole hours." }, { status: 400 });
      }
      studentChanges.dailyStudyHours = value;
    }
    if (body.studyPreference !== undefined) {
      const value = typeof body.studyPreference === "string" ? body.studyPreference : "";
      if (!preferenceValues.has(value)) return NextResponse.json({ error: "Choose a valid study preference." }, { status: 400 });
      studentChanges.studyPreference = value;
    }

    if (Object.keys(studentChanges).length > 0) {
      await db.update(students).set(studentChanges).where(eq(students.id, 1));
      changed = true;
    }

    if (body.topicId !== undefined) {
      const topicId = Number(body.topicId);
      const difficulty = typeof body.difficulty === "string" ? body.difficulty : "";
      if (!Number.isInteger(topicId) || !difficultyValues.has(difficulty)) {
        return NextResponse.json({ error: "Choose a valid topic and difficulty." }, { status: 400 });
      }
      const updated = await db
        .update(topics)
        .set({ difficulty })
        .where(and(eq(topics.id, topicId), eq(topics.studentId, 1)))
        .returning();
      if (updated.length === 0) return NextResponse.json({ error: "That syllabus topic was not found." }, { status: 404 });
      changed = true;
    }

    if (body.topic !== undefined) {
      if (!body.topic || typeof body.topic !== "object") {
        return NextResponse.json({ error: "Enter a topic to add." }, { status: 400 });
      }
      const newTopic = body.topic as Record<string, unknown>;
      const name = typeof newTopic.name === "string" ? newTopic.name.trim() : "";
      const description = typeof newTopic.description === "string" ? newTopic.description.trim().slice(0, 1000) : "";
      const difficulty = typeof newTopic.difficulty === "string" ? newTopic.difficulty : "Medium";
      if (!name || name.length > 120 || !difficultyValues.has(difficulty)) {
        return NextResponse.json({ error: "Enter a topic name up to 120 characters and choose a difficulty." }, { status: 400 });
      }

      const existingTopics = await db.select().from(topics).where(eq(topics.studentId, 1)).orderBy(asc(topics.position));
      if (existingTopics.some((topic) => topic.name.toLowerCase() === name.toLowerCase())) {
        return NextResponse.json({ error: "That topic is already in your syllabus." }, { status: 409 });
      }
      const knownNames = new Set(existingTopics.map((topic) => topic.name));
      const requestedPrerequisites = Array.isArray(newTopic.prerequisites)
        ? newTopic.prerequisites.filter((item): item is string => typeof item === "string")
        : [];
      const prerequisites = [...new Set(requestedPrerequisites)].filter((item) => knownNames.has(item) && item !== name).slice(0, 8);
      const position = existingTopics.reduce((maximum, topic) => Math.max(maximum, topic.position), 0) + 1;
      await db.insert(topics).values({
        studentId: 1,
        name,
        description,
        difficulty,
        prerequisites,
        position,
      });
      changed = true;
    }

    if (!changed) return NextResponse.json({ error: "Make a profile or syllabus change first." }, { status: 400 });

    const rebuiltCount = await rebuildUnfinishedPlan(1);
    const [student] = await db.select().from(students).where(eq(students.id, 1)).limit(1);
    return NextResponse.json({ message: "Your setup has been saved and the unfinished plan refreshed.", student, rebuiltCount });
  } catch (error) {
    console.error("Student setup update failed:", error);
    return NextResponse.json({ error: "Your setup could not be saved. Check the database connection and try again." }, { status: 500 });
  }
}

import ReviseRightApp from "@/components/revise-right-app";

export default function HomePage() {
  return <ReviseRightApp />;
}

export const topicSeeds = [
  {
    name: "Processes",
    description: "Process lifecycle, process control blocks, context switches, and process versus thread basics.",
    difficulty: "Medium",
    prerequisites: [],
    position: 1,
  },
  {
    name: "CPU Scheduling",
    description: "FCFS, SJF, priority scheduling, Round Robin, and turnaround / waiting-time calculations.",
    difficulty: "Hard",
    prerequisites: ["Processes"],
    position: 2,
  },
  {
    name: "Deadlocks",
    description: "The four necessary conditions, prevention, avoidance, detection, and recovery.",
    difficulty: "Hard",
    prerequisites: ["Processes"],
    position: 3,
  },
  {
    name: "Memory Management",
    description: "Address spaces, allocation, fragmentation, swapping, and virtual-memory fundamentals.",
    difficulty: "Medium",
    prerequisites: ["Processes"],
    position: 4,
  },
  {
    name: "Paging",
    description: "Pages and frames, address translation, page tables, TLBs, and page faults.",
    difficulty: "Hard",
    prerequisites: ["Memory Management"],
    position: 5,
  },
];

export type ResourceKind = "Video" | "Notes" | "Documentation" | "Practice";

export const resources: Array<{
  id: string;
  title: string;
  kind: ResourceKind;
  provider: string;
  url: string;
  topics: string[];
  why: string;
  level: string;
}> = [
  {
    id: "mit-process-video",
    title: "Operating systems: a worked example",
    kind: "Video",
    provider: "MIT OpenCourseWare",
    url: "https://ocw.mit.edu/courses/electrical-engineering-and-computer-science/6-004-computation-structures-spring-2017/c17/c17s2/c17s2v6/operating-systems/",
    topics: ["Processes", "CPU Scheduling"],
    why: "A visual worked example follows process state and the scheduler as control moves between processes.",
    level: "Beginner friendly",
  },
  {
    id: "mit-deadlock-video",
    title: "Deadlock — topic video",
    kind: "Video",
    provider: "MIT OpenCourseWare",
    url: "https://ocw.mit.edu/courses/6-004-computation-structures-spring-2017/resources/deadlock-7-36-/",
    topics: ["Deadlocks"],
    why: "A short MIT lecture video introduces deadlock using concrete synchronization examples.",
    level: "Beginner friendly",
  },
  {
    id: "ostep-book",
    title: "Operating Systems: Three Easy Pieces",
    kind: "Notes",
    provider: "University of Wisconsin–Madison authors",
    url: "https://pages.cs.wisc.edu/~remzi/OSTEP/",
    topics: ["Processes", "CPU Scheduling", "Deadlocks", "Memory Management", "Paging"],
    why: "A free, carefully explained textbook. Read one matching chapter, then summarize the idea from memory.",
    level: "Foundational",
  },
  {
    id: "linux-scheduler-docs",
    title: "CFS scheduler design document",
    kind: "Documentation",
    provider: "Linux kernel documentation",
    url: "https://docs.kernel.org/scheduler/sched-design-CFS.html",
    topics: ["CPU Scheduling"],
    why: "Connects scheduling theory to a real kernel scheduler; use it after you can compare FCFS, SJF, and Round Robin.",
    level: "Intermediate",
  },
  {
    id: "linux-memory-docs",
    title: "Memory Management — admin guide",
    kind: "Documentation",
    provider: "Linux kernel documentation",
    url: "https://docs.kernel.org/admin-guide/mm/index.html",
    topics: ["Memory Management", "Paging"],
    why: "The official Linux guide shows how memory-management concepts appear in a production kernel.",
    level: "Intermediate",
  },
  {
    id: "xv6-page-table-lab",
    title: "Lab: page tables",
    kind: "Practice",
    provider: "MIT 6.1810 Operating System Engineering",
    url: "https://pdos.csail.mit.edu/6.1810/2024/labs/pgtbl.html",
    topics: ["Memory Management", "Paging"],
    why: "A genuine xv6 lab asks you to inspect page tables and implement page-table features. It is optional and more advanced than exam practice.",
    level: "Advanced · optional",
  },
  {
    id: "xv6-process-lab",
    title: "Lab: xv6 and Unix utilities",
    kind: "Practice",
    provider: "MIT 6.1810 Operating System Engineering",
    url: "https://pdos.csail.mit.edu/6.1810/2024/labs/util.html",
    topics: ["Processes"],
    why: "The official lab uses fork, pipes, and system calls to make process behavior tangible. Treat it as an enrichment assignment.",
    level: "Intermediate · optional",
  },
];

export interface PlannerStudent {
  dailyStudyHours: number;
  studyPreference: string;
}

export interface PlannerTopic {
  name: string;
  difficulty: string;
  prerequisites: string[];
  position?: number;
}

export interface PlannerAttempt {
  topicName: string;
  correct: boolean;
  confidence: string;
}

export interface PlannerSessionInput {
  topicName: string | null;
  title: string;
  sessionType: string;
  scheduledDate: string;
  startTime: string;
  durationMinutes: number;
  status: string;
}

const preferenceBlocks: Record<string, Array<{ type: string; title: string }>> = {
  balanced: [
    { type: "Learn", title: "Learn the core ideas" },
    { type: "Practice", title: "Solve focused problems" },
    { type: "Revision", title: "Active recall and self-check" },
    { type: "Practice", title: "Work through an exam example" },
  ],
  reading: [
    { type: "Learn", title: "Read and annotate key concepts" },
    { type: "Practice", title: "Write a worked example" },
    { type: "Revision", title: "Summarize from memory" },
    { type: "Practice", title: "Check your notes with a problem" },
  ],
  video: [
    { type: "Learn", title: "Watch a focused lesson" },
    { type: "Practice", title: "Pause and solve an example" },
    { type: "Revision", title: "Teach the idea back aloud" },
    { type: "Practice", title: "Try a short self-check" },
  ],
  practice: [
    { type: "Practice", title: "Solve exam-style questions" },
    { type: "Learn", title: "Review any tricky steps" },
    { type: "Revision", title: "Correct and explain mistakes" },
    { type: "Practice", title: "Try a timed question" },
  ],
};

function topicPriority(
  topic: PlannerTopic,
  attempts: PlannerAttempt[],
  unfinished: PlannerSessionInput[],
  topics: PlannerTopic[],
): number {
  const topicAttempts = attempts.filter((attempt) => attempt.topicName === topic.name);
  const scheduledUnfinished = unfinished.filter((session) => session.topicName === topic.name && session.status !== "completed").length;
  const hardChildNeedsFoundation = topics.some((child) => {
    if (!child.prerequisites.includes(topic.name)) return false;
    const childAttempts = attempts.filter((attempt) => attempt.topicName === child.name);
    return childAttempts.length === 0 || childAttempts.filter((attempt) => attempt.correct).length / childAttempts.length < 0.7;
  });
  const difficultyScore = topic.difficulty.toLowerCase() === "hard" ? 12 : topic.difficulty.toLowerCase() === "medium" ? 7 : 3;

  if (topicAttempts.length === 0) {
    return 42 + difficultyScore + (hardChildNeedsFoundation ? 17 : 0) + Math.min(12, scheduledUnfinished * 3);
  }

  const accuracy = topicAttempts.filter((attempt) => attempt.correct).length / topicAttempts.length;
  const lowConfidenceShare = topicAttempts.filter((attempt) => attempt.confidence === "Low").length / topicAttempts.length;
  const overconfidentErrors = topicAttempts.filter((attempt) => !attempt.correct && attempt.confidence === "High").length;
  const attemptGap = Math.max(0, 4 - topicAttempts.length) * 2;

  return (
    (1 - accuracy) * 58 +
    lowConfidenceShare * 26 +
    (overconfidentErrors > 0 ? Math.min(18, overconfidentErrors * 7) : 0) +
    difficultyScore +
    attemptGap +
    (hardChildNeedsFoundation ? 13 : 0) +
    Math.min(12, scheduledUnfinished * 3)
  );
}

function dateAfter(startDate: string, offset: number): string {
  const date = new Date(`${startDate}T12:00:00.000Z`);
  date.setUTCDate(date.getUTCDate() + offset);
  return date.toISOString().slice(0, 10);
}

function formatClock(totalMinutes: number): string {
  const hours = Math.floor(totalMinutes / 60) % 24;
  const minutes = totalMinutes % 60;
  return `${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}`;
}

export function planWindowLength(examDate: string, startDate: string, limit = 7): number {
  const exam = new Date(`${examDate}T12:00:00.000Z`).getTime();
  const start = new Date(`${startDate}T12:00:00.000Z`).getTime();
  if (!Number.isFinite(exam) || !Number.isFinite(start) || exam < start) return 0;
  const daysUntilExam = Math.floor((exam - start) / 86_400_000) + 1;
  return Math.min(Math.max(0, limit), daysUntilExam);
}

export function buildStudyPlan(
  student: PlannerStudent,
  topics: PlannerTopic[],
  attempts: PlannerAttempt[],
  existingSessions: PlannerSessionInput[],
  startDate: string,
  days = 7,
): PlannerSessionInput[] {
  if (topics.length === 0) return [];

  const hours = Math.max(1, Math.min(8, Math.round(student.dailyStudyHours || 2)));
  const blockCount = Math.min(4, Math.max(2, Math.ceil(hours * 1.5)));
  const breakMinutes = 10;
  const blocks = preferenceBlocks[student.studyPreference] ?? preferenceBlocks.balanced;
  const rankedTopics = [...topics].sort((a, b) => {
    const scoreDifference = topicPriority(b, attempts, existingSessions, topics) - topicPriority(a, attempts, existingSessions, topics);
    return scoreDifference || (a.position ?? 0) - (b.position ?? 0);
  });
  const result: PlannerSessionInput[] = [];

  for (let dayIndex = 0; dayIndex < days; dayIndex += 1) {
    const scheduledDate = dateAfter(startDate, dayIndex);
    const completedMinutes = existingSessions
      .filter((session) => session.status === "completed" && session.scheduledDate === scheduledDate)
      .reduce((sum, session) => sum + session.durationMinutes, 0);
    const dayBudget = Math.max(0, hours * 60 - completedMinutes);
    if (dayBudget < 25) continue;

    const dayBlockCount = Math.min(blockCount, Math.max(1, Math.floor((dayBudget + breakMinutes) / 35)));
    const focusMinutes = Math.min(
      50,
      Math.max(25, Math.floor((dayBudget - breakMinutes * Math.max(0, dayBlockCount - 1)) / dayBlockCount)),
    );
    let clockMinutes = 17 * 60;

    for (let blockIndex = 0; blockIndex < dayBlockCount; blockIndex += 1) {
      const topic = rankedTopics[(dayIndex * blockCount + blockIndex) % rankedTopics.length];
      const activity = blocks[blockIndex % blocks.length];
      result.push({
        topicName: topic.name,
        title: activity.title,
        sessionType: activity.type,
        scheduledDate,
        startTime: formatClock(clockMinutes),
        durationMinutes: focusMinutes,
        status: "planned",
      });
      clockMinutes += focusMinutes;

      if (blockIndex < dayBlockCount - 1 && clockMinutes + breakMinutes < 23 * 60) {
        result.push({
          topicName: null,
          title: "Step away, stretch, and reset",
          sessionType: "Break",
          scheduledDate,
          startTime: formatClock(clockMinutes),
          durationMinutes: breakMinutes,
          status: "planned",
        });
        clockMinutes += breakMinutes;
      }
    }
  }

  return result;
}

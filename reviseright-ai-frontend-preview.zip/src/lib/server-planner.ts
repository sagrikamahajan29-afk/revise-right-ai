import { and, asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { quizAttempts, students, studySessions, topics } from "@/db/schema";
import { buildStudyPlan, planWindowLength } from "@/lib/planner";

export function currentDateString(): string {
  return new Date().toISOString().slice(0, 10);
}

export async function rebuildUnfinishedPlan(studentId = 1) {
  const [student] = await db.select().from(students).where(eq(students.id, studentId)).limit(1);
  if (!student) throw new Error("Student profile not found.");

  const studentTopics = await db
    .select()
    .from(topics)
    .where(eq(topics.studentId, studentId))
    .orderBy(asc(topics.position), asc(topics.id));
  const attempts = await db.select().from(quizAttempts).where(eq(quizAttempts.studentId, studentId));
  const existingSessions = await db.select().from(studySessions).where(eq(studySessions.studentId, studentId));
  const today = currentDateString();
  const days = planWindowLength(student.examDate, today, 7);
  const plan = buildStudyPlan(student, studentTopics, attempts, existingSessions, today, days);

  await db
    .delete(studySessions)
    .where(and(eq(studySessions.studentId, studentId), eq(studySessions.status, "planned")));

  if (plan.length > 0) {
    await db.insert(studySessions).values(plan.map((session) => ({ ...session, studentId })));
  }

  return plan.length;
}

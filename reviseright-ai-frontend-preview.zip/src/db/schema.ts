import { sql } from "drizzle-orm";
import {
  boolean,
  date,
  index,
  integer,
  jsonb,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
  varchar,
} from "drizzle-orm/pg-core";

export const students = pgTable("students", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 100 }).notNull().default("Student"),
  subject: varchar("subject", { length: 120 }).notNull().default("Operating Systems"),
  examDate: date("exam_date", { mode: "string" }).notNull(),
  dailyStudyHours: integer("daily_study_hours").notNull().default(2),
  studyPreference: varchar("study_preference", { length: 24 }).notNull().default("balanced"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const topics = pgTable(
  "topics",
  {
    id: serial("id").primaryKey(),
    studentId: integer("student_id")
      .notNull()
      .references(() => students.id, { onDelete: "cascade" }),
    name: varchar("name", { length: 120 }).notNull(),
    description: text("description").notNull().default(""),
    difficulty: varchar("difficulty", { length: 16 }).notNull().default("Medium"),
    prerequisites: jsonb("prerequisites").$type<string[]>().notNull().default(sql`'[]'::jsonb`),
    position: integer("position").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    uniqueIndex("topics_student_name_unique").on(table.studentId, table.name),
    index("topics_student_idx").on(table.studentId),
  ],
);

export const quizAttempts = pgTable(
  "quiz_attempts",
  {
    id: serial("id").primaryKey(),
    studentId: integer("student_id")
      .notNull()
      .references(() => students.id, { onDelete: "cascade" }),
    topicName: varchar("topic_name", { length: 120 }).notNull(),
    questionId: varchar("question_id", { length: 80 }).notNull(),
    assessmentId: varchar("assessment_id", { length: 40 }).notNull(),
    answerIndex: integer("answer_index").notNull(),
    correct: boolean("correct").notNull(),
    confidence: varchar("confidence", { length: 12 }).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    index("quiz_attempts_student_topic_idx").on(table.studentId, table.topicName),
    index("quiz_attempts_created_idx").on(table.createdAt),
  ],
);

export const studySessions = pgTable(
  "study_sessions",
  {
    id: serial("id").primaryKey(),
    studentId: integer("student_id")
      .notNull()
      .references(() => students.id, { onDelete: "cascade" }),
    topicName: varchar("topic_name", { length: 120 }),
    title: varchar("title", { length: 180 }).notNull(),
    sessionType: varchar("session_type", { length: 24 }).notNull(),
    scheduledDate: date("scheduled_date", { mode: "string" }).notNull(),
    startTime: varchar("start_time", { length: 5 }).notNull(),
    durationMinutes: integer("duration_minutes").notNull(),
    status: varchar("status", { length: 16 }).notNull().default("planned"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    index("study_sessions_student_date_idx").on(table.studentId, table.scheduledDate),
    index("study_sessions_student_status_idx").on(table.studentId, table.status),
  ],
);

"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import type { CSSProperties, FormEvent, ReactNode } from "react";
import { resources } from "@/lib/catalog";

type PageId = "dashboard" | "syllabus" | "quiz" | "gaps" | "planner" | "resources" | "map" | "analytics";
type Confidence = "Low" | "Medium" | "High";
type Difficulty = "Easy" | "Medium" | "Hard";

type Student = {
  id: number;
  name: string;
  subject: string;
  examDate: string;
  dailyStudyHours: number;
  studyPreference: string;
};

type Topic = {
  id: number;
  studentId: number;
  name: string;
  description: string;
  difficulty: Difficulty | string;
  prerequisites: string[];
  position: number;
};

type Attempt = {
  id: number;
  studentId: number;
  topicName: string;
  questionId: string;
  assessmentId: string;
  answerIndex: number;
  correct: boolean;
  confidence: Confidence;
  createdAt: string;
};

type StudySession = {
  id: number;
  studentId: number;
  topicName: string | null;
  title: string;
  sessionType: string;
  scheduledDate: string;
  startTime: string;
  durationMinutes: number;
  status: "planned" | "completed" | string;
};

type AppData = {
  student: Student;
  topics: Topic[];
  attempts: Attempt[];
  sessions: StudySession[];
};

type PublicQuestion = {
  id: string;
  topicName: string;
  prompt: string;
  options: string[];
  difficulty: Difficulty;
};

type QuizFeedback = {
  questionId: string;
  topicName: string;
  prompt: string;
  options: string[];
  selectedIndex: number;
  correctIndex: number;
  correct: boolean;
  confidence: Confidence;
  explanation: string;
};

type IconName =
  | "grid"
  | "book"
  | "quiz"
  | "target"
  | "calendar"
  | "sparkle"
  | "map"
  | "chart"
  | "arrow"
  | "check"
  | "clock"
  | "play"
  | "trend"
  | "chevron"
  | "plus"
  | "external"
  | "menu"
  | "close"
  | "refresh"
  | "coffee"
  | "download"
  | "info"
  | "alert"
  | "bookmark"
  | "award"
  | "bookOpen"
  | "arrowDown"
  | "leaf"
  | "send"
  | "sliders"
  | "shield";

const iconDrawings: Record<IconName, ReactNode> = {
  grid: <><rect x="3.5" y="3.5" width="7" height="7" rx="1.5" /><rect x="13.5" y="3.5" width="7" height="7" rx="1.5" /><rect x="3.5" y="13.5" width="7" height="7" rx="1.5" /><rect x="13.5" y="13.5" width="7" height="7" rx="1.5" /></>,
  book: <><path d="M4 5.5A2.5 2.5 0 0 1 6.5 3H20v16H6.5A2.5 2.5 0 0 0 4 21.5z" /><path d="M4 5.5v16M8 7h8M8 11h8" /></>,
  quiz: <><path d="M8 6h13M8 12h13M8 18h13" /><path d="m3.5 6 .8.8L5.8 5M3.5 12l.8.8L5.8 11M3.5 18l.8.8L5.8 17" /></>,
  target: <><circle cx="12" cy="12" r="9" /><circle cx="12" cy="12" r="5" /><circle cx="12" cy="12" r="1.2" /></>,
  calendar: <><rect x="3" y="5" width="18" height="16" rx="2" /><path d="M16 3v4M8 3v4M3 10h18" /></>,
  sparkle: <><path d="m12 3 1.3 5.2L18.5 10l-5.2 1.4L12 17l-1.3-5.6L5.5 10l5.2-1.8z" /><path d="m19 15 .7 2.3L22 18l-2.3.7L19 21l-.7-2.3L16 18l2.3-.7z" /></>,
  map: <><path d="m3 6 6-3 6 3 6-3v15l-6 3-6-3-6 3z" /><path d="M9 3v15M15 6v15" /></>,
  chart: <><path d="M4 19V5M4 19h17" /><path d="m7 15 4-4 3 2 5-7" /><path d="M16 6h3v3" /></>,
  arrow: <><path d="M7 17 17 7M8 7h9v9" /></>,
  check: <path d="m5 12 4 4L19 6" />,
  clock: <><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3.5 2" /></>,
  play: <><path d="m9 6 10 6-10 6z" /></>,
  trend: <><path d="M3 17 9 11l4 4 8-9" /><path d="M15 6h6v6" /></>,
  chevron: <path d="m9 18 6-6-6-6" />,
  plus: <><path d="M12 5v14M5 12h14" /></>,
  external: <><path d="M14 4h6v6M20 4l-9 9" /><path d="M18 13v6a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h6" /></>,
  menu: <><path d="M4 6h16M4 12h16M4 18h16" /></>,
  close: <><path d="m18 6-12 12M6 6l12 12" /></>,
  refresh: <><path d="M20 7v5h-5" /><path d="M4 17v-5h5" /><path d="M5.6 9A7 7 0 0 1 18.2 6L20 8M4 16l1.8 2A7 7 0 0 0 18.4 15" /></>,
  coffee: <><path d="M4 9h13v6a4 4 0 0 1-4 4H8a4 4 0 0 1-4-4z" /><path d="M17 11h1a2 2 0 0 1 0 4h-1M8 3v2M12 3v2M16 3v2" /></>,
  download: <><path d="M12 3v12M7 10l5 5 5-5" /><path d="M5 20h14" /></>,
  info: <><circle cx="12" cy="12" r="9" /><path d="M12 11v5M12 8h.01" /></>,
  alert: <><path d="m12 3 10 18H2z" /><path d="M12 9v4M12 17h.01" /></>,
  bookmark: <><path d="M6 4a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v17l-6-4-6 4z" /></>,
  award: <><circle cx="12" cy="8" r="5" /><path d="m8.5 12-1 9 4.5-2.5 4.5 2.5-1-9" /></>,
  bookOpen: <><path d="M3 5.5A2.5 2.5 0 0 1 5.5 3H12v17H5.5A2.5 2.5 0 0 0 3 22z" /><path d="M21 5.5A2.5 2.5 0 0 0 18.5 3H12v17h6.5a2.5 2.5 0 0 1 2.5 2z" /></>,
  arrowDown: <><path d="M12 4v15M6 13l6 6 6-6" /></>,
  leaf: <><path d="M20 4c-8 0-14 3-14 10a6 6 0 0 0 6 6c7 0 10-6 8-16Z" /><path d="M4 21c3-5 7-8 12-11" /></>,
  send: <><path d="m22 2-7 20-4-9-9-4z" /><path d="M22 2 11 13" /></>,
  sliders: <><path d="M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3" /><path d="M2 14h4M10 8h4M18 16h4" /></>,
  shield: <><path d="M12 22s8-4 8-11V5l-8-3-8 3v6c0 7 8 11 8 11z" /><path d="m9 12 2 2 4-4" /></>,
};

function Icon({ name, size = 18, className = "" }: { name: IconName; size?: number; className?: string }) {
  return (
    <svg
      className={className}
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      {iconDrawings[name]}
    </svg>
  );
}

const builtInTopics = ["Processes", "CPU Scheduling", "Deadlocks", "Memory Management", "Paging"];

const navigation: Array<{ section: string; items: Array<{ id: PageId; label: string; icon: IconName }> }> = [
  { section: "OVERVIEW", items: [{ id: "dashboard", label: "Dashboard", icon: "grid" }] },
  {
    section: "STUDY TOOLS",
    items: [
      { id: "syllabus", label: "My syllabus", icon: "book" },
      { id: "quiz", label: "Take a quiz", icon: "quiz" },
      { id: "gaps", label: "Learning gaps", icon: "target" },
      { id: "planner", label: "Study planner", icon: "calendar" },
    ],
  },
  {
    section: "DISCOVER",
    items: [
      { id: "resources", label: "Learning resources", icon: "sparkle" },
      { id: "map", label: "Prerequisite map", icon: "map" },
      { id: "analytics", label: "Progress analytics", icon: "chart" },
    ],
  },
];

const pageNames: Record<PageId, string> = {
  dashboard: "Dashboard",
  syllabus: "My syllabus",
  quiz: "Take a quiz",
  gaps: "Learning gaps",
  planner: "Smart study planner",
  resources: "Learning resources",
  map: "Prerequisite learning map",
  analytics: "Progress analytics",
};

async function requestJson<T>(url: string, init?: RequestInit): Promise<T> {
  const response = await fetch(url, {
    ...init,
    cache: "no-store",
    headers: { "Content-Type": "application/json", ...init?.headers },
  });
  const payload = (await response.json().catch(() => ({}))) as { error?: string } & T;
  if (!response.ok) throw new Error(payload.error ?? "Something went wrong. Please try again.");
  return payload;
}

function todayIso(): string {
  return new Date().toISOString().slice(0, 10);
}

function daysUntil(examDate: string): number {
  const exam = new Date(`${examDate}T12:00:00.000Z`).getTime();
  const today = new Date(`${todayIso()}T12:00:00.000Z`).getTime();
  return Math.ceil((exam - today) / 86_400_000);
}

function readableDate(value: string, options: Intl.DateTimeFormatOptions = { month: "short", day: "numeric" }): string {
  const date = new Date(`${value}T12:00:00.000Z`);
  return Number.isFinite(date.getTime()) ? date.toLocaleDateString("en-US", options) : value;
}

function dayTitle(value: string): string {
  const date = new Date(`${value}T12:00:00.000Z`);
  return date.toLocaleDateString("en-US", { weekday: "long" });
}

function dayAbbreviation(value: string): string {
  const date = new Date(`${value}T12:00:00.000Z`);
  return date.toLocaleDateString("en-US", { weekday: "short" });
}

function formatClock(value: string): string {
  const [hourValue, minuteValue] = value.split(":").map(Number);
  const hour = hourValue ?? 0;
  const minute = minuteValue ?? 0;
  const suffix = hour >= 12 ? "PM" : "AM";
  const twelveHour = hour % 12 || 12;
  return `${twelveHour}:${String(minute).padStart(2, "0")} ${suffix}`;
}

function formatDuration(minutes: number): string {
  if (minutes < 60) return `${minutes} min`;
  const hours = Math.floor(minutes / 60);
  const remainder = minutes % 60;
  return remainder ? `${hours}h ${remainder}m` : `${hours}h`;
}

function confidenceNumber(value: Confidence): number {
  if (value === "High") return 3;
  if (value === "Medium") return 2;
  return 1;
}

function topicStats(topicName: string, attempts: Attempt[]) {
  const rows = attempts.filter((attempt) => attempt.topicName === topicName);
  const correctCount = rows.filter((attempt) => attempt.correct).length;
  const lowConfidenceCount = rows.filter((attempt) => attempt.confidence === "Low").length;
  const highConfidenceErrors = rows.filter((attempt) => !attempt.correct && attempt.confidence === "High").length;
  const accuracy = rows.length ? Math.round((correctCount / rows.length) * 100) : null;
  const lowShare = rows.length ? lowConfidenceCount / rows.length : 0;
  let priority = "Steady";
  let reason = "Recent answers are holding steady. Keep this topic fresh with occasional active recall.";

  if (rows.length === 0) {
    priority = "Not assessed";
    reason = "There is no saved quiz evidence for this topic yet. Take a short baseline quiz before drawing conclusions.";
  } else if ((accuracy ?? 100) < 50 || lowShare >= 0.6) {
    priority = "High";
    const details = [];
    if ((accuracy ?? 100) < 50) details.push(`${accuracy}% accuracy across ${rows.length} answer${rows.length === 1 ? "" : "s"}`);
    if (lowShare >= 0.6) details.push(`${lowConfidenceCount} answer${lowConfidenceCount === 1 ? " was" : "s were"} marked low confidence`);
    reason = `${details.join(" and ")}. Revisit the core idea, then try a few practice questions.`;
  } else if ((accuracy ?? 100) < 75 || lowConfidenceCount > 0 || highConfidenceErrors > 0) {
    priority = "Medium";
    if (highConfidenceErrors > 0) {
      reason = `There ${highConfidenceErrors === 1 ? "is" : "are"} ${highConfidenceErrors} high-confidence incorrect answer${highConfidenceErrors === 1 ? "" : "s"}; check for a misconception before moving on.`;
    } else if ((accuracy ?? 100) < 75) {
      reason = `Accuracy is ${accuracy}% over ${rows.length} answer${rows.length === 1 ? "" : "s"}. A focused practice set can reinforce the steps.`;
    } else {
      reason = `${lowConfidenceCount} answer${lowConfidenceCount === 1 ? " was" : "s were"} marked low confidence. Revisit the explanation and use active recall.`;
    }
  }

  return {
    attempts: rows,
    count: rows.length,
    correctCount,
    accuracy,
    lowConfidenceCount,
    highConfidenceErrors,
    priority,
    reason,
    needsPractice: rows.length > 0 && priority !== "Steady",
  };
}

function priorityRank(priority: string): number {
  if (priority === "High") return 0;
  if (priority === "Medium") return 1;
  if (priority === "Not assessed") return 2;
  return 3;
}

function averageAccuracy(attempts: Attempt[]): number | null {
  if (attempts.length === 0) return null;
  return Math.round((attempts.filter((attempt) => attempt.correct).length / attempts.length) * 100);
}

function groupSessions(sessions: StudySession[]) {
  const groups = new Map<string, StudySession[]>();
  for (const session of [...sessions].sort((a, b) => a.scheduledDate.localeCompare(b.scheduledDate) || a.startTime.localeCompare(b.startTime))) {
    const existing = groups.get(session.scheduledDate) ?? [];
    existing.push(session);
    groups.set(session.scheduledDate, existing);
  }
  return [...groups.entries()].map(([date, items]) => ({ date, items }));
}

function coveragePercent(data: AppData): number {
  if (data.topics.length === 0) return 0;
  const covered = data.topics.filter((topic) => data.attempts.some((attempt) => attempt.topicName === topic.name)).length;
  return Math.round((covered / data.topics.length) * 100);
}

function PageHeader({
  eyebrow,
  title,
  description,
  action,
}: {
  eyebrow: string;
  title: string;
  description: string;
  action?: ReactNode;
}) {
  return (
    <div className="page-heading">
      <div>
        <p className="eyebrow">{eyebrow}</p>
        <h1>{title}</h1>
        <p className="page-description">{description}</p>
      </div>
      {action ? <div className="heading-action">{action}</div> : null}
    </div>
  );
}

function StatCard({
  label,
  value,
  note,
  icon,
  tone = "blue",
}: {
  label: string;
  value: string;
  note: string;
  icon: IconName;
  tone?: "blue" | "green" | "violet" | "amber";
}) {
  return (
    <article className="stat-card">
      <div className={`stat-icon stat-icon--${tone}`}><Icon name={icon} size={19} /></div>
      <div className="stat-copy">
        <span className="stat-label">{label}</span>
        <strong>{value}</strong>
        <small>{note}</small>
      </div>
      <span className={`stat-glow stat-glow--${tone}`} aria-hidden="true" />
    </article>
  );
}

function InlineEmpty({ icon, title, body, action }: { icon: IconName; title: string; body: string; action?: ReactNode }) {
  return (
    <div className="empty-state">
      <span className="empty-icon"><Icon name={icon} size={21} /></span>
      <h3>{title}</h3>
      <p>{body}</p>
      {action}
    </div>
  );
}

function PriorityPill({ priority }: { priority: string }) {
  const tone = priority === "High" ? "high" : priority === "Medium" ? "medium" : priority === "Steady" ? "steady" : "neutral";
  return <span className={`priority-pill priority-pill--${tone}`}><span className="pill-dot" />{priority}</span>;
}

function DashboardPage({
  data,
  onNavigate,
  onStartQuiz,
  onComplete,
  busy,
}: {
  data: AppData;
  onNavigate: (page: PageId) => void;
  onStartQuiz: (topic?: string) => void;
  onComplete: (session: StudySession) => void;
  busy: string;
}) {
  const totalAttempts = data.attempts.length;
  const accuracy = averageAccuracy(data.attempts);
  const covered = data.topics.filter((topic) => data.attempts.some((attempt) => attempt.topicName === topic.name)).length;
  const completedCount = data.sessions.filter((session) => session.status === "completed" && session.sessionType !== "Break").length;
  const examDays = daysUntil(data.student.examDate);
  const firstName = data.student.name.trim().split(/\s+/)[0] || "there";
  const dates = Array.from({ length: 7 }, (_, index) => {
    const date = new Date(`${todayIso()}T12:00:00.000Z`);
    date.setUTCDate(date.getUTCDate() + index);
    return date.toISOString().slice(0, 10);
  });
  const chartMax = Math.max(60, data.student.dailyStudyHours * 60);
  const todaySessions = data.sessions.filter((session) => session.scheduledDate === todayIso());
  const recommended = data.topics
    .map((topic) => ({ topic, stats: topicStats(topic.name, data.attempts) }))
    .sort((a, b) => priorityRank(a.stats.priority) - priorityRank(b.stats.priority) || (b.stats.accuracy ?? -1) - (a.stats.accuracy ?? -1))[0];

  return (
    <>
      <section className="welcome-banner">
        <div className="welcome-copy">
          <span className="welcome-kicker"><Icon name="sparkle" size={15} /> YOUR REVISION SPACE</span>
          <h2>Good to see you, {firstName}.</h2>
          <p>Small, focused sessions add up. Your next step is ready when you are.</p>
          <div className="welcome-actions">
            <button className="button button--white" onClick={() => onStartQuiz()}><Icon name="play" size={16} /> Start a quick quiz</button>
            <button className="button button--ghost-light" onClick={() => onNavigate("planner")}>View my plan <Icon name="chevron" size={16} /></button>
          </div>
        </div>
        <div className="exam-countdown-card">
          <div className="countdown-orbit"><Icon name="calendar" size={20} /></div>
          <span className="countdown-label">EXAM COUNTDOWN</span>
          <strong>{examDays < 0 ? "—" : examDays}</strong>
          <span className="countdown-days">{examDays < 0 ? "date passed" : examDays === 1 ? "day to go" : "days to go"}</span>
          <div className="countdown-divider" />
          <span className="countdown-date">{readableDate(data.student.examDate, { month: "short", day: "numeric", year: "numeric" })}</span>
        </div>
        <div className="welcome-shape welcome-shape--one" />
        <div className="welcome-shape welcome-shape--two" />
      </section>

      <div className="stats-grid">
        <StatCard label="Syllabus covered" value={`${covered} / ${data.topics.length}`} note={`${coveragePercent(data)}% assessed at least once`} icon="bookOpen" tone="blue" />
        <StatCard label="Quiz accuracy" value={accuracy === null ? "—" : `${accuracy}%`} note={totalAttempts === 0 ? "No attempts saved yet" : `${totalAttempts} answer${totalAttempts === 1 ? "" : "s"} checked`} icon="target" tone="green" />
        <StatCard label="Sessions completed" value={`${completedCount}`} note="Recorded study blocks · no streak assumed" icon="check" tone="violet" />
        <StatCard label="Daily study time" value={`${data.student.dailyStudyHours}h`} note="Your current planner setting" icon="clock" tone="amber" />
      </div>

      <div className="dashboard-grid">
        <section className="panel focus-panel">
          <div className="panel-heading">
            <div>
              <span className="section-kicker">YOUR ROUTINE</span>
              <h2>Focus this week</h2>
            </div>
            <button className="text-button" onClick={() => onNavigate("planner")}>Open planner <Icon name="arrow" size={15} /></button>
          </div>
          <div className="chart-summary-row">
            <div><span className="chart-summary-number">{formatDuration(data.sessions.filter((session) => session.status === "planned" && session.sessionType !== "Break").reduce((sum, session) => sum + session.durationMinutes, 0))}</span><span className="chart-summary-label">planned focus</span></div>
            <span className="chart-separator" />
            <div><span className="chart-summary-number chart-summary-number--green">{formatDuration(data.sessions.filter((session) => session.status === "completed" && session.sessionType !== "Break").reduce((sum, session) => sum + session.durationMinutes, 0))}</span><span className="chart-summary-label">completed focus</span></div>
          </div>
          <div className="week-chart" role="img" aria-label="Planned and completed focus time for the coming seven days">
            {dates.map((date) => {
              const daySessions = data.sessions.filter((session) => session.scheduledDate === date && session.sessionType !== "Break");
              const plannedMinutes = daySessions.filter((session) => session.status === "planned").reduce((sum, session) => sum + session.durationMinutes, 0);
              const completedMinutes = daySessions.filter((session) => session.status === "completed").reduce((sum, session) => sum + session.durationMinutes, 0);
              const plannedHeight = Math.max(plannedMinutes > 0 ? 5 : 0, Math.min(100, (plannedMinutes / chartMax) * 100));
              const completeHeight = Math.min(100, (completedMinutes / chartMax) * 100);
              return (
                <div className="week-chart-day" key={date}>
                  <div className="week-chart-value">{plannedMinutes ? `${Math.round(plannedMinutes / 60 * 10) / 10}h` : ""}</div>
                  <div className="week-chart-track">
                    <span className="week-chart-planned" style={{ height: `${plannedHeight}%` }} />
                    <span className="week-chart-completed" style={{ height: `${completeHeight}%` }} />
                  </div>
                  <span className={`week-chart-label ${date === todayIso() ? "week-chart-label--today" : ""}`}>{dayAbbreviation(date)}</span>
                </div>
              );
            })}
          </div>
          <div className="chart-legend"><span><i className="legend-square legend-square--planned" /> Planned</span><span><i className="legend-square legend-square--completed" /> Completed</span></div>
          <p className="chart-footnote">Planned hours come from your timetable; completed time appears only after you mark a session done.</p>
        </section>

        <section className="panel agenda-panel">
          <div className="panel-heading">
            <div><span className="section-kicker">{todayIso() === data.sessions[0]?.scheduledDate ? "TODAY" : "YOUR SCHEDULE"}</span><h2>Today’s agenda</h2></div>
            <button className="icon-button icon-button--quiet" aria-label="Open study planner" onClick={() => onNavigate("planner")}><Icon name="arrow" size={17} /></button>
          </div>
          {todaySessions.length > 0 ? (
            <div className="agenda-list">
              {todaySessions.slice(0, 4).map((session) => (
                <AgendaItem key={session.id} session={session} onComplete={onComplete} busy={busy} compact />
              ))}
              {todaySessions.length > 4 ? <button className="text-button agenda-more" onClick={() => onNavigate("planner")}>+ {todaySessions.length - 4} more in your plan</button> : null}
            </div>
          ) : (
            <InlineEmpty
              icon="coffee"
              title="No sessions on today’s plan"
              body={examDays < 0 ? "Update your exam date in My syllabus to build a fresh plan." : "Your timetable may start tomorrow, or your study window is already complete."}
              action={<button className="text-button" onClick={() => onNavigate("planner")}>Review timetable <Icon name="arrow" size={14} /></button>}
            />
          )}
        </section>
      </div>

      <div className="dashboard-lower-grid">
        <section className="panel next-step-panel">
          <div className="panel-heading">
            <div><span className="section-kicker">A GOOD NEXT STEP</span><h2>{recommended?.stats.priority === "Not assessed" ? "Build your baseline" : "Practice with purpose"}</h2></div>
            <span className="panel-heading-icon"><Icon name="sparkle" size={18} /></span>
          </div>
          {recommended ? (
            <div className="next-step-body">
              <div className="next-topic-mark"><span>{String(recommended.topic.position).padStart(2, "0")}</span></div>
              <div className="next-topic-copy">
                <div className="next-topic-title-row"><strong>{recommended.topic.name}</strong><PriorityPill priority={recommended.stats.priority} /></div>
                <p>{recommended.stats.reason}</p>
                <button className="text-button" onClick={() => onStartQuiz(recommended.topic.name)}>{recommended.stats.priority === "Not assessed" ? "Take a baseline quiz" : "Practice this topic"}<Icon name="arrow" size={14} /></button>
              </div>
            </div>
          ) : <p className="muted-copy">Add topics to your syllabus to see a suggested next step.</p>}
        </section>
        <section className="panel encouragement-panel">
          <span className="encouragement-mark"><Icon name="leaf" size={21} /></span>
          <div><span className="section-kicker">A NOTE FOR TODAY</span><h2>Progress is practice, not perfection.</h2><p>Confidence is useful data too. Rate it honestly so your revision plan can focus on what needs a second look.</p></div>
          <button className="text-button" onClick={() => onNavigate("gaps")}>How learning gaps work <Icon name="arrow" size={14} /></button>
        </section>
      </div>
    </>
  );
}

function AgendaItem({
  session,
  onComplete,
  busy,
  compact = false,
}: {
  session: StudySession;
  onComplete: (session: StudySession) => void;
  busy: string;
  compact?: boolean;
}) {
  const isBreak = session.sessionType === "Break";
  const complete = session.status === "completed";
  return (
    <article className={`agenda-item ${complete ? "agenda-item--complete" : ""} ${isBreak ? "agenda-item--break" : ""} ${compact ? "agenda-item--compact" : ""}`}>
      <div className={`agenda-time-line ${isBreak ? "agenda-time-line--break" : ""}`}><span className="agenda-time-dot" /></div>
      <div className="agenda-time">{formatClock(session.startTime)}</div>
      <div className="agenda-item-content">
        <span className={`session-type session-type--${session.sessionType.toLowerCase()}`}>{isBreak ? <Icon name="coffee" size={12} /> : null}{session.sessionType}</span>
        <strong>{isBreak ? session.title : session.topicName}</strong>
        <span className="agenda-session-title">{isBreak ? "A short reset" : session.title}</span>
      </div>
      <div className="agenda-item-end">
        <span className="session-duration">{formatDuration(session.durationMinutes)}</span>
        {!isBreak ? (
          <button
            className={`complete-session-button ${complete ? "is-complete" : ""}`}
            onClick={() => onComplete(session)}
            disabled={busy === `session-${session.id}`}
            aria-label={complete ? `Undo completion for ${session.topicName}` : `Mark ${session.topicName} as completed`}
          >
            <Icon name="check" size={14} />{compact ? "" : complete ? "Done" : "Mark done"}
          </button>
        ) : null}
      </div>
    </article>
  );
}

function WeekChart({ data }: { data: AppData }) {
  const dates = Array.from({ length: 7 }, (_, index) => {
    const date = new Date(`${todayIso()}T12:00:00.000Z`);
    date.setUTCDate(date.getUTCDate() + index);
    return date.toISOString().slice(0, 10);
  });
  const chartMax = Math.max(60, data.student.dailyStudyHours * 60);
  return (
    <div className="week-chart" role="img" aria-label="Planned and completed focus time for the coming seven days">
      {dates.map((date) => {
        const daySessions = data.sessions.filter((session) => session.scheduledDate === date && session.sessionType !== "Break");
        const plannedMinutes = daySessions.filter((session) => session.status === "planned").reduce((sum, session) => sum + session.durationMinutes, 0);
        const completedMinutes = daySessions.filter((session) => session.status === "completed").reduce((sum, session) => sum + session.durationMinutes, 0);
        const plannedHeight = Math.max(plannedMinutes > 0 ? 5 : 0, Math.min(100, (plannedMinutes / chartMax) * 100));
        const completeHeight = Math.min(100, (completedMinutes / chartMax) * 100);
        return (
          <div className="week-chart-day" key={date}>
            <div className="week-chart-value">{plannedMinutes ? `${Math.round(plannedMinutes / 60 * 10) / 10}h` : ""}</div>
            <div className="week-chart-track"><span className="week-chart-planned" style={{ height: `${plannedHeight}%` }} /><span className="week-chart-completed" style={{ height: `${completeHeight}%` }} /></div>
            <span className={`week-chart-label ${date === todayIso() ? "week-chart-label--today" : ""}`}>{dayAbbreviation(date)}</span>
          </div>
        );
      })}
    </div>
  );
}

function SyllabusPage({
  data,
  busy,
  onSaveProfile,
  onAddTopic,
  onDifficulty,
  onStartQuiz,
}: {
  data: AppData;
  busy: string;
  onSaveProfile: (values: Record<string, unknown>) => Promise<void>;
  onAddTopic: (topic: Record<string, unknown>) => Promise<void>;
  onDifficulty: (topicId: number, difficulty: string) => void;
  onStartQuiz: (topic?: string) => void;
}) {
  const assessedCount = data.topics.filter((topic) => data.attempts.some((attempt) => attempt.topicName === topic.name)).length;
  const [name, setName] = useState(data.student.name);
  const [subject, setSubject] = useState(data.student.subject);
  const [examDate, setExamDate] = useState(data.student.examDate);
  const [dailyHours, setDailyHours] = useState(String(data.student.dailyStudyHours));
  const [preference, setPreference] = useState(data.student.studyPreference);
  const [topicName, setTopicName] = useState("");
  const [topicDescription, setTopicDescription] = useState("");
  const [topicDifficulty, setTopicDifficulty] = useState("Medium");
  const [prerequisites, setPrerequisites] = useState<string[]>([]);

  function submitProfile(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    void onSaveProfile({ name, subject, examDate, dailyStudyHours: Number(dailyHours), studyPreference: preference });
  }

  function submitTopic(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!topicName.trim()) return;
    void onAddTopic({ name: topicName, description: topicDescription, difficulty: topicDifficulty, prerequisites }).then(() => {
      setTopicName("");
      setTopicDescription("");
      setTopicDifficulty("Medium");
      setPrerequisites([]);
    });
  }

  return (
    <>
      <PageHeader eyebrow="YOUR LEARNING SETUP" title="My syllabus" description="Set your exam context, make the plan yours, and track every topic in one place." />
      <section className="syllabus-overview panel">
        <div className="syllabus-overview-copy">
          <span className="overview-icon"><Icon name="bookOpen" size={19} /></span>
          <div><span className="section-kicker">{data.student.subject.toUpperCase()}</span><h2>{data.topics.length} topics in your syllabus</h2><p>{assessedCount} of {data.topics.length} topics have at least one saved diagnostic answer. Coverage is based on evidence, not a preset score.</p></div>
        </div>
        <div className="syllabus-progress-wrap"><div className="syllabus-progress-label"><strong>{coveragePercent(data)}%</strong><span>assessed</span></div><div className="progress-track"><span style={{ width: `${coveragePercent(data)}%` }} /></div><button className="text-button" onClick={() => onStartQuiz()}>Take a diagnostic <Icon name="arrow" size={14} /></button></div>
      </section>

      <div className="syllabus-layout">
        <div className="syllabus-main-column">
          <section className="panel topic-list-panel">
            <div className="panel-heading panel-heading--with-count"><div><span className="section-kicker">TOPIC CHECKLIST</span><h2>Course topics</h2></div><span className="subtle-count">{data.topics.length} topics</span></div>
            <div className="topic-list">
              {data.topics.map((topic, index) => {
                const stats = topicStats(topic.name, data.attempts);
                const supported = builtInTopics.includes(topic.name);
                return (
                  <article className="topic-row" key={topic.id}>
                    <div className="topic-number">{String(index + 1).padStart(2, "0")}</div>
                    <div className="topic-row-content">
                      <div className="topic-row-title"><h3>{topic.name}</h3><PriorityPill priority={stats.priority} /></div>
                      <p>{topic.description || "Custom syllabus topic"}</p>
                      {topic.prerequisites.length > 0 ? <div className="prerequisite-tags">Builds on {topic.prerequisites.map((item) => <span key={item}>{item}</span>)}</div> : null}
                      <div className="topic-row-meta"><span>{stats.count === 0 ? "No quiz attempts yet" : `${stats.correctCount}/${stats.count} correct · ${stats.accuracy}% accuracy`}</span><span className="meta-divider" /><span>{topic.difficulty} difficulty</span></div>
                    </div>
                    <div className="topic-row-tools">
                      <label className="sr-only" htmlFor={`difficulty-${topic.id}`}>Difficulty for {topic.name}</label>
                      <select id={`difficulty-${topic.id}`} className="small-select" value={topic.difficulty} onChange={(event) => onDifficulty(topic.id, event.target.value)} disabled={busy === `difficulty-${topic.id}`}>
                        <option>Easy</option><option>Medium</option><option>Hard</option>
                      </select>
                      {supported ? <button className="topic-quiz-button" onClick={() => onStartQuiz(topic.name)} aria-label={`Quiz ${topic.name}`}><Icon name="play" size={14} /></button> : <span className="custom-topic-badge">Custom</span>}
                    </div>
                  </article>
                );
              })}
            </div>
            <div className="custom-question-note"><Icon name="info" size={16} /><p>Custom topics are included in your plan and progress map. The built-in diagnostic question bank currently covers the five Operating Systems topics above.</p></div>
          </section>

          <section className="panel add-topic-panel">
            <div className="panel-heading"><div><span className="section-kicker">MAKE IT YOURS</span><h2>Add a syllabus topic</h2></div><span className="panel-heading-icon panel-heading-icon--green"><Icon name="plus" size={19} /></span></div>
            <form className="form-grid" onSubmit={submitTopic}>
              <label className="field field--wide"><span>Topic name</span><input value={topicName} onChange={(event) => setTopicName(event.target.value)} maxLength={120} placeholder="e.g. File systems" required /></label>
              <label className="field"><span>Difficulty</span><select value={topicDifficulty} onChange={(event) => setTopicDifficulty(event.target.value)}><option>Easy</option><option>Medium</option><option>Hard</option></select></label>
              <label className="field field--wide"><span>Short description <small>optional</small></span><textarea value={topicDescription} onChange={(event) => setTopicDescription(event.target.value)} maxLength={1000} rows={2} placeholder="What should you be able to explain or solve?" /></label>
              <div className="field field--wide"><span>Prerequisite topics <small>optional</small></span><div className="prerequisite-checkboxes">{data.topics.map((topic) => <label className="checkbox-chip" key={topic.id}><input type="checkbox" checked={prerequisites.includes(topic.name)} onChange={(event) => setPrerequisites((current) => event.target.checked ? [...current, topic.name] : current.filter((item) => item !== topic.name))} /><span>{topic.name}</span></label>)}</div></div>
              <div className="form-submit-row"><span className="form-hint">New topics are added to your adaptive study plan.</span><button className="button button--primary" type="submit" disabled={busy === "add-topic" || !topicName.trim()}>{busy === "add-topic" ? "Adding…" : <><Icon name="plus" size={15} /> Add topic</>}</button></div>
            </form>
          </section>
        </div>

        <aside className="syllabus-side-column">
          <section className="panel setup-panel">
            <div className="panel-heading"><div><span className="section-kicker">STUDENT SETUP</span><h2>Study profile</h2></div><span className="panel-heading-icon"><Icon name="sliders" size={18} /></span></div>
            <p className="panel-intro">Your schedule is generated from these settings. Change them whenever your week changes.</p>
            <form className="setup-form" onSubmit={submitProfile}>
              <label className="field"><span>Your name</span><input value={name} onChange={(event) => setName(event.target.value)} maxLength={100} required /></label>
              <label className="field"><span>Subject</span><input value={subject} onChange={(event) => setSubject(event.target.value)} maxLength={120} required /></label>
              <label className="field"><span>Exam date</span><input type="date" value={examDate} onChange={(event) => setExamDate(event.target.value)} required /></label>
              <label className="field"><span>Available study hours / day</span><select value={dailyHours} onChange={(event) => setDailyHours(event.target.value)}>{[1, 2, 3, 4, 5, 6, 7, 8].map((hours) => <option key={hours} value={hours}>{hours} hour{hours === 1 ? "" : "s"}</option>)}</select></label>
              <label className="field"><span>Study preference</span><select value={preference} onChange={(event) => setPreference(event.target.value)}><option value="balanced">Balanced mix</option><option value="reading">Reading and notes</option><option value="video">Video lessons</option><option value="practice">Practice first</option></select></label>
              <button className="button button--primary button--full" type="submit" disabled={busy === "profile"}>{busy === "profile" ? "Saving profile…" : <><Icon name="check" size={16} /> Save study profile</>}</button>
            </form>
            <div className="database-note"><span className="sync-indicator" /><span>Saved to your PostgreSQL workspace</span></div>
          </section>
          <section className="callout-card callout-card--soft"><span className="callout-icon"><Icon name="info" size={17} /></span><div><strong>A focused starter library</strong><p>The ready-made questions and resources cover Operating Systems. Your custom topics are still tracked and scheduled, but need their own question bank for diagnostics.</p></div></section>
        </aside>
      </div>
    </>
  );
}

function QuizPage({
  mode,
  topic,
  questions,
  index,
  selected,
  confidence,
  feedback,
  currentFeedback,
  loading,
  saving,
  error,
  setTopic,
  setSelected,
  setConfidence,
  onStart,
  onCheck,
  onContinue,
}: {
  mode: "idle" | "loading" | "active" | "finished";
  topic: string;
  questions: PublicQuestion[];
  index: number;
  selected: number | null;
  confidence: Confidence | null;
  feedback: QuizFeedback[];
  currentFeedback: QuizFeedback | null;
  loading: boolean;
  saving: boolean;
  error: string;
  setTopic: (topic: string) => void;
  setSelected: (index: number | null) => void;
  setConfidence: (confidence: Confidence | null) => void;
  onStart: () => void;
  onCheck: () => void;
  onContinue: () => void;
}) {
  const currentQuestion = questions[index];
  const score = feedback.filter((item) => item.correct).length;
  const progress = questions.length ? ((index + (currentFeedback ? 1 : 0)) / questions.length) * 100 : 0;

  return (
    <>
      <PageHeader eyebrow="ACTIVE RECALL" title="Take a quiz" description="Check what you know, rate your confidence, and get an explanation for every answer." />
      {mode === "idle" || mode === "loading" ? (
        <div className="quiz-start-layout">
          <section className="quiz-intro-card">
            <div className="quiz-intro-art"><div className="quiz-art-sheet"><span /><span /><span /></div><div className="quiz-art-check"><Icon name="check" size={22} /></div><span className="quiz-art-spark quiz-art-spark--one">✦</span><span className="quiz-art-spark quiz-art-spark--two">✧</span></div>
            <div className="quiz-intro-copy"><span className="section-kicker">A QUICK KNOWLEDGE CHECK</span><h2>Practice is how recall gets stronger.</h2><p>Answer each question, rate how confident you feel, and use the feedback to decide what to revisit next. Your results are saved to your profile.</p><div className="quiz-benefits"><span><Icon name="check" size={15} /> Answer-by-answer feedback</span><span><Icon name="check" size={15} /> Honest confidence tracking</span><span><Icon name="check" size={15} /> No timer pressure</span></div></div>
          </section>
          <section className="panel quiz-launch-panel">
            <div className="panel-heading"><div><span className="section-kicker">CHOOSE YOUR FOCUS</span><h2>Set up a quiz</h2></div><span className="panel-heading-icon panel-heading-icon--violet"><Icon name="target" size={18} /></span></div>
            <label className="field"><span>Quiz topic</span><select value={topic} onChange={(event) => setTopic(event.target.value)}><option value="all">A little of everything · 5 questions</option>{builtInTopics.map((name) => <option key={name} value={name}>{name} · 3 questions</option>)}</select></label>
            <div className="quiz-launch-info"><div><Icon name="clock" size={16} /><span>About 3–5 minutes</span></div><div><Icon name="bookmark" size={16} /><span>Results saved to Progress Analytics</span></div></div>
            {error ? <p className="inline-error">{error}</p> : null}
            <button className="button button--primary button--full" onClick={onStart} disabled={loading}>{loading ? <><span className="button-spinner" /> Preparing questions…</> : <><Icon name="play" size={16} /> Begin diagnostic</>}</button>
            <p className="quiz-launch-footnote">Built-in diagnostic questions currently cover Operating Systems.</p>
          </section>
        </div>
      ) : null}

      {mode === "active" && currentQuestion ? (
        <div className="quiz-workspace">
          <div className="quiz-progress-top"><span>QUESTION {String(index + 1).padStart(2, "0")} <i>OF</i> {String(questions.length).padStart(2, "0")}</span><span>{currentQuestion.topicName}<b className="difficulty-dot" />{currentQuestion.difficulty}</span></div>
          <div className="quiz-progress-track"><span style={{ width: `${Math.max(7, progress)}%` }} /></div>
          <section className="panel quiz-question-card">
            <div className="quiz-question-label"><span className="question-number-badge">Q{index + 1}</span><span className="topic-tag">{currentQuestion.topicName}</span><span className={`difficulty-label difficulty-label--${currentQuestion.difficulty.toLowerCase()}`}>{currentQuestion.difficulty}</span></div>
            <h2>{currentQuestion.prompt}</h2>
            <div className="answer-options">
              {currentQuestion.options.map((option, optionIndex) => {
                const isSelected = selected === optionIndex;
                const isCorrect = currentFeedback?.correctIndex === optionIndex;
                const isWrongSelected = currentFeedback && currentFeedback.selectedIndex === optionIndex && !currentFeedback.correct;
                return (
                  <button
                    className={`answer-option ${isSelected ? "answer-option--selected" : ""} ${currentFeedback && isCorrect ? "answer-option--correct" : ""} ${isWrongSelected ? "answer-option--wrong" : ""}`}
                    key={`${currentQuestion.id}-${optionIndex}`}
                    onClick={() => !currentFeedback && setSelected(optionIndex)}
                    disabled={Boolean(currentFeedback)}
                    aria-pressed={isSelected}
                  >
                    <span className="option-letter">{String.fromCharCode(65 + optionIndex)}</span><span className="option-copy">{option}</span>
                    {currentFeedback && isCorrect ? <span className="option-status"><Icon name="check" size={16} /></span> : null}
                    {isWrongSelected ? <span className="option-status option-status--wrong"><Icon name="close" size={15} /></span> : null}
                  </button>
                );
              })}
            </div>

            {!currentFeedback ? (
              <div className="confidence-block">
                <div><strong>How confident are you?</strong><span>This helps the coach spot uncertain knowledge.</span></div>
                <div className="confidence-choices" role="group" aria-label="Choose your confidence rating">
                  {(["Low", "Medium", "High"] as Confidence[]).map((value) => <button type="button" key={value} className={`confidence-choice confidence-choice--${value.toLowerCase()} ${confidence === value ? "is-selected" : ""}`} onClick={() => setConfidence(value)} aria-pressed={confidence === value}>{value}</button>)}
                </div>
              </div>
            ) : (
              <div className={`answer-feedback ${currentFeedback.correct ? "answer-feedback--correct" : "answer-feedback--incorrect"}`}>
                <span className="feedback-symbol"><Icon name={currentFeedback.correct ? "check" : "info"} size={17} /></span>
                <div><strong>{currentFeedback.correct ? "That’s right." : "Not quite — here’s the idea."}</strong><p>{currentFeedback.explanation}</p><span className="feedback-confidence">You rated this {currentFeedback.confidence.toLowerCase()} confidence.</span></div>
              </div>
            )}
            {error ? <p className="inline-error">{error}</p> : null}
            <div className="quiz-question-footer"><span className="saved-answer-note"><Icon name="shield" size={15} /> {currentFeedback ? "Answer saved" : "Your answer is checked and saved when you continue"}</span>
              {!currentFeedback ? <button className="button button--primary" onClick={onCheck} disabled={selected === null || confidence === null || saving}>{saving ? <><span className="button-spinner" /> Checking…</> : <>Check answer <Icon name="arrow" size={15} /></>}</button> : <button className="button button--primary" onClick={onContinue}>{index === questions.length - 1 ? "See quiz results" : "Next question"}<Icon name="chevron" size={15} /></button>}
            </div>
          </section>
          <div className="quiz-microcopy"><Icon name="info" size={14} /> Confidence is a self-rating, not a score. A high-confidence mistake can be a useful signal to revisit a concept.</div>
        </div>
      ) : null}

      {mode === "finished" ? (
        <div className="quiz-results-page">
          <section className="quiz-result-hero">
            <span className="result-check-mark"><Icon name={score === feedback.length ? "award" : "trend"} size={24} /></span>
            <span className="section-kicker">QUIZ COMPLETE · {topic === "all" ? "ALL TOPICS" : topic.toUpperCase()}</span>
            <h2>{score} <span>/ {feedback.length}</span></h2>
            <p>{feedback.length === 0 ? "No answers were recorded in this quiz." : `${Math.round((score / feedback.length) * 100)}% correct on this attempt. Use the explanations below to plan a useful next step.`}</p>
            <div className="result-hero-actions"><button className="button button--primary" onClick={onStart}><Icon name="refresh" size={15} /> Try another quiz</button><span className="result-saved"><Icon name="check" size={14} /> Saved to your progress</span></div>
          </section>
          <section className="panel result-review-panel"><div className="panel-heading"><div><span className="section-kicker">REVIEW YOUR THINKING</span><h2>Answer review</h2></div><span className="subtle-count">{feedback.length} questions</span></div>
            <div className="result-review-list">{feedback.map((item, resultIndex) => <article className="result-review-item" key={item.questionId}><div className={`review-result-icon ${item.correct ? "is-correct" : "is-incorrect"}`}><Icon name={item.correct ? "check" : "close"} size={15} /></div><div className="review-answer-body"><div className="review-answer-title"><span>Q{resultIndex + 1} · {item.topicName}</span><span className="review-confidence">{item.confidence} confidence</span></div><h3>{item.prompt}</h3><p className="review-selected-answer"><strong>Your answer:</strong> {item.options[item.selectedIndex]} {item.correct ? <span className="answer-correct-word">· Correct</span> : <span className="answer-incorrect-word">· Revisit</span>}</p>{!item.correct ? <p className="review-correct-answer"><strong>Correct answer:</strong> {item.options[item.correctIndex]}</p> : null}<p className="review-explanation">{item.explanation}</p></div></article>)}</div>
          </section>
        </div>
      ) : null}
    </>
  );
}

function LearningGapsPage({ data, onStartQuiz }: { data: AppData; onStartQuiz: (topic?: string) => void }) {
  const rows = data.topics
    .map((topic) => ({ topic, stats: topicStats(topic.name, data.attempts) }))
    .sort((a, b) => priorityRank(a.stats.priority) - priorityRank(b.stats.priority) || (a.stats.accuracy ?? -1) - (b.stats.accuracy ?? -1));
  const assessed = rows.filter((row) => row.stats.count > 0);
  const highCount = assessed.filter((row) => row.stats.priority === "High").length;
  const flaggedCount = assessed.filter((row) => row.stats.needsPractice).length;
  const unassessedCount = rows.filter((row) => row.stats.count === 0).length;

  return (
    <>
      <PageHeader eyebrow="EXPLAINABLE RECOMMENDATIONS" title="Learning gaps" description="A transparent look at what may need another pass, based on your saved answers and confidence ratings." action={<button className="button button--primary" onClick={() => onStartQuiz()}><Icon name="play" size={15} /> Take a diagnostic</button>} />
      <div className="stats-grid stats-grid--three">
        <StatCard label="Topics to revisit" value={`${flaggedCount}`} note="Assessed topics with a review signal" icon="target" tone="violet" />
        <StatCard label="High priority" value={`${highCount}`} note="Low accuracy or repeated low confidence" icon="alert" tone="amber" />
        <StatCard label="Not assessed yet" value={`${unassessedCount}`} note="No saved answers; no gap is assumed" icon="book" tone="blue" />
      </div>
      <div className="gaps-layout">
        <section className="panel gap-list-panel"><div className="panel-heading"><div><span className="section-kicker">TOPIC-BY-TOPIC</span><h2>What to revisit next</h2></div><span className="subtle-count">{rows.length} topics</span></div>
          {rows.length ? <div className="gap-list">{rows.map(({ topic, stats }, index) => {
            const supported = builtInTopics.includes(topic.name);
            return <article className={`gap-row ${stats.priority === "High" ? "gap-row--high" : ""}`} key={topic.id}><div className="gap-order">{String(index + 1).padStart(2, "0")}</div><div className={`gap-topic-icon ${stats.priority === "High" ? "gap-topic-icon--high" : stats.priority === "Not assessed" ? "gap-topic-icon--new" : ""}`}><Icon name={stats.priority === "Not assessed" ? "bookmark" : stats.priority === "Steady" ? "check" : "target"} size={17} /></div><div className="gap-copy"><div className="gap-title-row"><h3>{topic.name}</h3><PriorityPill priority={stats.priority} /></div><p>{stats.reason}</p><div className="gap-meta">{stats.count > 0 ? <><span>{stats.accuracy}% accuracy</span><span className="meta-divider" /><span>{stats.count} answer{stats.count === 1 ? "" : "s"}</span><span className="meta-divider" /><span>{stats.lowConfidenceCount} low confidence</span></> : <span>Baseline needed · not a detected gap</span>}</div></div><div className="gap-action">{supported ? <button className="button button--outline button--small" onClick={() => onStartQuiz(topic.name)}>{stats.count === 0 ? "Assess" : "Practice"}<Icon name="arrow" size={14} /></button> : <span className="custom-topic-badge">Custom topic</span>}</div></article>;
          })}</div> : <InlineEmpty icon="target" title="No syllabus topics yet" body="Add the topics you want to track in My syllabus." />}
        </section>
        <aside className="panel gap-explain-panel"><span className="explain-mark"><Icon name="sparkle" size={20} /></span><span className="section-kicker">HOW THIS WORKS</span><h2>Clues, not black-box scores.</h2><p>These recommendations use simple rules you can inspect. They are study suggestions, not grades or predictions.</p><div className="rule-list"><div><span className="rule-number">01</span><p><strong>Accuracy</strong> — a topic below 75% gets a practice nudge; below 50% is marked high priority.</p></div><div><span className="rule-number">02</span><p><strong>Confidence</strong> — repeated low-confidence answers suggest you may benefit from another explanation.</p></div><div><span className="rule-number">03</span><p><strong>Misconceptions</strong> — a wrong answer rated high confidence is highlighted for a careful review.</p></div><div><span className="rule-number">04</span><p><strong>No attempt</strong> — shown as “Not assessed,” never treated as a failed result.</p></div></div><div className="explain-footer"><Icon name="info" size={15} /><span>More practice changes the evidence and refreshes the recommendations.</span></div></aside>
      </div>
    </>
  );
}

function PlannerPage({
  data,
  busy,
  onComplete,
  onGenerate,
  onReschedule,
}: {
  data: AppData;
  busy: string;
  onComplete: (session: StudySession) => void;
  onGenerate: () => void;
  onReschedule: (hours: number) => void;
}) {
  const [availableHours, setAvailableHours] = useState(String(data.student.dailyStudyHours));
  const examDays = daysUntil(data.student.examDate);
  const planGroups = groupSessions(data.sessions);
  const nextPlan = data.sessions.filter((session) => session.status === "planned" && session.sessionType !== "Break");
  const doneCount = data.sessions.filter((session) => session.status === "completed" && session.sessionType !== "Break").length;

  return (
    <>
      <PageHeader eyebrow="A PLAN THAT ADAPTS" title="Smart study planner" description="Short, structured work blocks based on your exam date, available time, topic priorities, and prerequisites." action={<button className="button button--outline" onClick={onGenerate} disabled={busy === "plan"}>{busy === "plan" ? <><span className="button-spinner button-spinner--dark" /> Updating…</> : <><Icon name="refresh" size={15} /> Refresh this week</>}</button>} />
      <section className="planner-summary-banner"><div className="planner-summary-icon"><Icon name="calendar" size={20} /></div><div className="planner-summary-copy"><span className="section-kicker">YOUR CURRENT PLAN</span><h2>{nextPlan.length} focus block{nextPlan.length === 1 ? "" : "s"} ready · {doneCount} completed</h2><p>{examDays < 0 ? "Your saved exam date has passed. Update it in My syllabus to create a fresh schedule." : `${examDays} day${examDays === 1 ? "" : "s"} until your exam · ${data.student.dailyStudyHours} available study hour${data.student.dailyStudyHours === 1 ? "" : "s"} each day · ${data.student.studyPreference} preference`}</p></div><div className="planner-summary-date"><span>EXAM DAY</span><strong>{readableDate(data.student.examDate, { month: "short", day: "numeric" })}</strong></div></section>
      <section className="panel reschedule-panel"><div className="reschedule-icon"><Icon name="refresh" size={19} /></div><div className="reschedule-copy"><span className="section-kicker">LIFE HAPPENS</span><h2>Missed a session or have less time?</h2><p>Rebuild unfinished blocks around your new availability. Completed sessions stay in your history, and your remaining topics are reprioritized.</p></div><div className="reschedule-controls"><label className="field"><span>Hours per day</span><select value={availableHours} onChange={(event) => setAvailableHours(event.target.value)}>{[1, 2, 3, 4, 5, 6, 7, 8].map((hours) => <option key={hours} value={hours}>{hours}h</option>)}</select></label><button className="button button--primary" onClick={() => onReschedule(Number(availableHours))} disabled={busy === "reschedule"}>{busy === "reschedule" ? "Replanning…" : "Reorganize sessions"}<Icon name="arrow" size={15} /></button></div></section>

      <section className="panel planner-timetable-panel"><div className="panel-heading"><div><span className="section-kicker">NEXT 7 DAYS · LOCAL STUDY BLOCKS</span><h2>Your timetable</h2></div><div className="planner-legend"><span><i className="legend-square legend-square--learn" /> Focus</span><span><i className="legend-square legend-square--break" /> Break</span><span><i className="legend-square legend-square--done" /> Completed</span></div></div>
        {planGroups.length ? <div className="planner-days">{planGroups.map(({ date, items }) => {
          const isToday = date === todayIso();
          const dateIsPast = date < todayIso();
          return <section className={`planner-day ${isToday ? "planner-day--today" : ""}`} key={date}><div className="planner-day-heading"><div className="planner-date-block"><span>{dayTitle(date)}</span><strong>{readableDate(date, { month: "short", day: "numeric" })}</strong>{isToday ? <em>Today</em> : null}</div><span className="planner-day-count">{items.filter((session) => session.sessionType !== "Break").length} focus blocks</span></div><div className="planner-day-sessions">{items.map((session) => <div className={`planner-session ${session.sessionType === "Break" ? "planner-session--break" : ""} ${session.status === "completed" ? "planner-session--completed" : ""} ${dateIsPast && session.status === "planned" ? "planner-session--overdue" : ""}`} key={session.id}><div className="planner-session-time">{formatClock(session.startTime)}</div><div className="planner-session-indicator">{session.sessionType === "Break" ? <Icon name="coffee" size={14} /> : session.status === "completed" ? <Icon name="check" size={15} /> : <span />}</div><div className="planner-session-copy"><span className={`session-type session-type--${session.sessionType.toLowerCase()}`}>{session.sessionType}</span><strong>{session.topicName ?? session.title}</strong><span>{session.topicName ? session.title : "Pause between focus blocks"}</span></div><span className="planner-session-duration">{formatDuration(session.durationMinutes)}</span>{session.sessionType !== "Break" ? <button className={`planner-done-button ${session.status === "completed" ? "is-done" : ""}`} onClick={() => onComplete(session)} disabled={busy === `session-${session.id}`}>{session.status === "completed" ? <><Icon name="check" size={14} /> Done</> : dateIsPast ? "Mark done" : "Mark done"}</button> : <span className="break-label">Reset</span>}</div>)}</div></section>;
        })}</div> : <InlineEmpty icon="calendar" title="No upcoming plan yet" body={examDays < 0 ? "Set a future exam date to schedule revision blocks." : "Refresh this week to generate a plan from your current topics and available hours."} action={<button className="button button--primary button--small" onClick={onGenerate}>Generate my plan</button>} />}
      </section>
      <div className="planner-method-note"><Icon name="info" size={15} /><p><strong>Why this order?</strong> Topics with no baseline, weaker accuracy, low confidence, or unfinished blocks receive more attention. Prerequisite topics are surfaced before concepts that build on them. This is an explainable rule-based plan, not an AI-generated prediction.</p></div>
    </>
  );
}

function ResourcesPage({ data, onStartQuiz }: { data: AppData; onStartQuiz: (topic?: string) => void }) {
  const [kindFilter, setKindFilter] = useState("All resources");
  const [topicFilter, setTopicFilter] = useState("All topics");
  const kindOptions = ["All resources", "Video", "Notes", "Documentation", "Practice"];
  const relevantGaps = data.topics
    .map((topic) => ({ topic, stats: topicStats(topic.name, data.attempts) }))
    .filter(({ stats }) => stats.priority === "High" || stats.priority === "Medium" || stats.priority === "Not assessed")
    .sort((a, b) => priorityRank(a.stats.priority) - priorityRank(b.stats.priority));
  const recommendedTopic = relevantGaps[0]?.topic.name;
  const filteredResources = resources
    .filter((resource) => kindFilter === "All resources" || resource.kind === kindFilter)
    .filter((resource) => topicFilter === "All topics" || resource.topics.includes(topicFilter))
    .sort((a, b) => {
      const aScore = recommendedTopic && a.topics.includes(recommendedTopic) ? 1 : 0;
      const bScore = recommendedTopic && b.topics.includes(recommendedTopic) ? 1 : 0;
      return bScore - aScore || a.title.localeCompare(b.title);
    });

  return (
    <>
      <PageHeader eyebrow="CURATED FOR YOUR COURSE" title="Learning resources" description="Open materials from real universities and documentation projects, matched to your syllabus with a reason to use each one." />
      {recommendedTopic ? <section className="resource-recommendation"><span className="resource-recommendation-icon"><Icon name="sparkle" size={17} /></span><div><span className="section-kicker">A USEFUL NEXT STEP</span><strong>Start with {recommendedTopic}</strong><p>{topicStats(recommendedTopic, data.attempts).reason}</p></div>{builtInTopics.includes(recommendedTopic) ? <button className="button button--outline button--small" onClick={() => onStartQuiz(recommendedTopic)}>Take a quiz <Icon name="arrow" size={14} /></button> : null}</section> : null}
      <section className="resource-toolbar"><div className="filter-tabs" role="group" aria-label="Filter resources by type">{kindOptions.map((kind) => <button className={kindFilter === kind ? "is-active" : ""} key={kind} onClick={() => setKindFilter(kind)}>{kind}</button>)}</div><label className="resource-topic-filter"><span>Topic</span><select value={topicFilter} onChange={(event) => setTopicFilter(event.target.value)}><option>All topics</option>{data.topics.map((topic) => <option key={topic.id}>{topic.name}</option>)}</select></label></section>
      <div className="resource-grid">{filteredResources.map((resource, index) => {
        const icon: IconName = resource.kind === "Video" ? "play" : resource.kind === "Notes" ? "bookOpen" : resource.kind === "Practice" ? "target" : "external";
        return <article className={`resource-card ${index === 0 && recommendedTopic && resource.topics.includes(recommendedTopic) ? "resource-card--recommended" : ""}`} key={resource.id}><div className="resource-card-top"><span className={`resource-kind-icon resource-kind-icon--${resource.kind.toLowerCase()}`}><Icon name={icon} size={17} /></span><span className="resource-kind-label">{resource.kind}</span>{index === 0 && recommendedTopic && resource.topics.includes(recommendedTopic) ? <span className="recommended-mini-badge">For you</span> : null}</div><p className="resource-provider">{resource.provider}</p><h2>{resource.title}</h2><p className="resource-why">{resource.why}</p><div className="resource-topic-tags">{resource.topics.map((topic) => <span key={topic}>{topic}</span>)}</div><div className="resource-card-footer"><span className="resource-level"><Icon name="info" size={13} />{resource.level}</span><a href={resource.url} target="_blank" rel="noreferrer" className="resource-open-link">Open resource <Icon name="external" size={14} /></a></div></article>;
      })}</div>
      {filteredResources.length === 0 ? <InlineEmpty icon="book" title="No resources match that filter" body="Choose another resource type or topic." /> : null}
      <p className="resource-disclaimer"><Icon name="info" size={14} /> External links open in a new tab. MIT, Linux kernel, and OSTEP content is maintained by its original publisher; advanced labs are marked optional.</p>
    </>
  );
}

const mapPositions: Record<string, string> = {
  Processes: "map-node--processes",
  "CPU Scheduling": "map-node--scheduling",
  Deadlocks: "map-node--deadlocks",
  "Memory Management": "map-node--memory",
  Paging: "map-node--paging",
};

function LearningMapPage({ data, onStartQuiz }: { data: AppData; onStartQuiz: (topic?: string) => void }) {
  const coreTopics = data.topics.filter((topic) => mapPositions[topic.name]);
  const extraTopics = data.topics.filter((topic) => !mapPositions[topic.name]);
  const nextFoundation = data.topics
    .map((topic) => ({ topic, stats: topicStats(topic.name, data.attempts) }))
    .sort((a, b) => priorityRank(a.stats.priority) - priorityRank(b.stats.priority))[0];

  return (
    <>
      <PageHeader eyebrow="LEARN IN THE RIGHT ORDER" title="Prerequisite learning map" description="See how foundational ideas connect. Follow an arrow when a topic builds on earlier knowledge." action={<button className="button button--outline" onClick={() => onStartQuiz()}><Icon name="quiz" size={15} /> Check my foundations</button>} />
      <section className="map-explainer-strip"><span className="map-explainer-icon"><Icon name="map" size={18} /></span><p><strong>Start with the foundation, then build outward.</strong> Processes supports CPU scheduling, deadlocks, and memory management. Paging builds on memory management. Your quiz evidence appears inside each topic.</p><div className="map-legend"><span><i className="map-legend-dot map-legend-dot--unassessed" /> Not assessed</span><span><i className="map-legend-dot map-legend-dot--review" /> Revisit</span><span><i className="map-legend-dot map-legend-dot--steady" /> Steady</span></div></section>
      <section className="panel learning-map-panel"><div className="panel-heading"><div><span className="section-kicker">OPERATING SYSTEMS · FOUNDATIONAL PATH</span><h2>Concept dependencies</h2></div><span className="map-foundation-label"><Icon name="leaf" size={14} /> Foundation first</span></div>
        <div className="map-scroll-wrap"><div className="map-stage">
          <svg className="map-connectors" viewBox="0 0 850 370" preserveAspectRatio="none" aria-hidden="true"><defs><marker id="map-arrow" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="5" markerHeight="5" orient="auto-start-reverse"><path d="M 0 0 L 10 5 L 0 10 z" /></marker></defs><path d="M210 181 C267 181 275 58 332 58" markerEnd="url(#map-arrow)" /><path d="M210 181 C260 181 277 181 332 181" markerEnd="url(#map-arrow)" /><path d="M210 181 C267 181 275 302 332 302" markerEnd="url(#map-arrow)" /><path d="M510 302 C560 302 586 302 640 302" markerEnd="url(#map-arrow)" /></svg>
          {coreTopics.map((topic) => {
            const stats = topicStats(topic.name, data.attempts);
            const position = mapPositions[topic.name];
            const canQuiz = builtInTopics.includes(topic.name);
            return <button className={`map-node ${position} ${stats.priority === "Steady" ? "map-node--steady" : stats.priority === "High" || stats.priority === "Medium" ? "map-node--review" : "map-node--unassessed"}`} key={topic.id} onClick={() => canQuiz && onStartQuiz(topic.name)} disabled={!canQuiz} title={canQuiz ? `Take a ${topic.name} quiz` : `${topic.name} topic`}><span className="map-node-number">{String(topic.position).padStart(2, "0")}</span><span className="map-node-main"><strong>{topic.name}</strong><small>{topic.prerequisites.length ? `Builds on ${topic.prerequisites.join(", ")}` : "Foundational topic"}</small><span className="map-node-status">{stats.count === 0 ? "Not assessed" : `${stats.accuracy}% accuracy · ${stats.count} answers`}</span></span><span className="map-node-chevron"><Icon name="chevron" size={15} /></span></button>;
          })}
        </div></div>
        {extraTopics.length > 0 ? <div className="custom-map-section"><span className="section-kicker">YOUR ADDED TOPICS</span><div className="custom-map-list">{extraTopics.map((topic) => <div className="custom-map-chip" key={topic.id}><span className="custom-map-dot" /><div><strong>{topic.name}</strong><small>{topic.prerequisites.length ? `Prerequisites: ${topic.prerequisites.join(", ")}` : "No prerequisites added"}</small></div><PriorityPill priority={topicStats(topic.name, data.attempts).priority} /></div>)}</div></div> : null}
      </section>
      <div className="map-bottom-grid"><section className="panel map-foundation-panel"><span className="section-kicker">START HERE</span><h2>{nextFoundation?.topic.name ?? "Add your topics"}</h2><p>{nextFoundation?.stats.reason ?? "Add topics to build your own prerequisite map."}</p>{nextFoundation && builtInTopics.includes(nextFoundation.topic.name) ? <button className="text-button" onClick={() => onStartQuiz(nextFoundation.topic.name)}>Assess this foundation <Icon name="arrow" size={14} /></button> : null}</section><section className="callout-card callout-card--map"><span className="callout-icon"><Icon name="info" size={17} /></span><div><strong>Why prerequisites matter</strong><p>If a later concept feels confusing, the missing piece may be earlier knowledge. Revisit the connected foundation instead of only rereading the advanced topic.</p></div></section></div>
    </>
  );
}

function AnalyticsPage({ data, onExport }: { data: AppData; onExport: () => void }) {
  const attempts = [...data.attempts].sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
  const allAccuracy = averageAccuracy(attempts);
  const completed = data.sessions.filter((session) => session.status === "completed" && session.sessionType !== "Break");
  const testedTopics = data.topics.filter((topic) => attempts.some((attempt) => attempt.topicName === topic.name)).length;
  const confidenceCounts: Record<Confidence, number> = { Low: 0, Medium: 0, High: 0 };
  for (const attempt of attempts) confidenceCounts[attempt.confidence] += 1;

  const assessments = new Map<string, { date: string; confidence: number[]; total: number; correct: number }>();
  const perTopicAssessments = new Map<string, Map<string, { date: string; total: number; correct: number }>>();
  for (const attempt of attempts) {
    const assessment = assessments.get(attempt.assessmentId) ?? { date: attempt.createdAt, confidence: [], total: 0, correct: 0 };
    assessment.date = attempt.createdAt < assessment.date ? attempt.createdAt : assessment.date;
    assessment.confidence.push(confidenceNumber(attempt.confidence));
    assessment.total += 1;
    if (attempt.correct) assessment.correct += 1;
    assessments.set(attempt.assessmentId, assessment);

    const topicAssessments = perTopicAssessments.get(attempt.topicName) ?? new Map();
    const topicAssessment = topicAssessments.get(attempt.assessmentId) ?? { date: attempt.createdAt, total: 0, correct: 0 };
    topicAssessment.date = attempt.createdAt < topicAssessment.date ? attempt.createdAt : topicAssessment.date;
    topicAssessment.total += 1;
    if (attempt.correct) topicAssessment.correct += 1;
    topicAssessments.set(attempt.assessmentId, topicAssessment);
    perTopicAssessments.set(attempt.topicName, topicAssessments);
  }
  const assessmentPoints = [...assessments.values()].sort((a, b) => a.date.localeCompare(b.date)).slice(-8);
  const points = assessmentPoints.map((assessment, index) => {
    const average = assessment.confidence.reduce((sum, value) => sum + value, 0) / assessment.confidence.length;
    const x = assessmentPoints.length === 1 ? 200 : 28 + (index * 344) / (assessmentPoints.length - 1);
    const y = 122 - ((average - 1) / 2) * 90;
    return { x, y, average, date: assessment.date };
  });
  const pointString = points.map((point) => `${point.x},${point.y}`).join(" ");

  return (
    <>
      <PageHeader eyebrow="REAL EVIDENCE, CLEARLY SHOWN" title="Progress analytics" description="Your quiz answers, self-rated confidence, and completed study blocks — no sample scores or invented streaks." action={<button className="button button--outline" onClick={onExport}><Icon name="download" size={15} /> Export my data</button>} />
      <div className="stats-grid">
        <StatCard label="Quiz accuracy" value={allAccuracy === null ? "—" : `${allAccuracy}%`} note={attempts.length === 0 ? "Waiting for your first quiz" : `Across ${attempts.length} saved answers`} icon="target" tone="blue" />
        <StatCard label="Syllabus assessed" value={`${testedTopics} / ${data.topics.length}`} note="Topics with at least one answer" icon="bookOpen" tone="green" />
        <StatCard label="Study sessions done" value={`${completed.length}`} note="Blocks you marked complete" icon="check" tone="violet" />
        <StatCard label="Quiz runs" value={`${assessments.size}`} note="Saved quiz sessions" icon="trend" tone="amber" />
      </div>

      <div className="analytics-main-grid">
        <section className="panel performance-panel"><div className="panel-heading"><div><span className="section-kicker">ACCURACY BY TOPIC</span><h2>Topic performance</h2></div><span className="panel-heading-icon"><Icon name="chart" size={18} /></span></div><p className="panel-intro">Every bar is calculated from checked answers. An unfilled row means there is not enough evidence yet.</p><div className="performance-list">{data.topics.map((topic) => { const stats = topicStats(topic.name, attempts); return <div className="performance-row" key={topic.id}><div className="performance-topic"><span>{topic.name}</span><small>{stats.count ? `${stats.count} answer${stats.count === 1 ? "" : "s"}` : "Not assessed"}</small></div><div className="performance-track"><span className={stats.accuracy !== null && stats.accuracy < 50 ? "performance-fill performance-fill--low" : "performance-fill"} style={{ width: `${stats.accuracy ?? 0}%` }} /></div><strong className={stats.accuracy === null ? "performance-value performance-value--empty" : "performance-value"}>{stats.accuracy === null ? "—" : `${stats.accuracy}%`}</strong></div>; })}</div></section>

        <section className="panel confidence-panel"><div className="panel-heading"><div><span className="section-kicker">SELF-RATED CONFIDENCE</span><h2>Confidence trend</h2></div><span className="panel-heading-icon panel-heading-icon--green"><Icon name="trend" size={18} /></span></div><p className="panel-intro">Average rating per quiz run (Low = 1, Medium = 2, High = 3). Confidence is self-reported, not an accuracy score.</p>
          {points.length > 0 ? <><div className="confidence-chart-wrap"><div className="confidence-axis-labels"><span>High</span><span>Medium</span><span>Low</span></div><svg className="confidence-chart" viewBox="0 0 400 140" role="img" aria-label="Average confidence trend across quiz runs"><line x1="20" y1="32" x2="380" y2="32" className="chart-grid-line" /><line x1="20" y1="77" x2="380" y2="77" className="chart-grid-line" /><line x1="20" y1="122" x2="380" y2="122" className="chart-grid-line" />{points.length > 1 ? <polyline points={pointString} fill="none" className="confidence-line" /> : null}{points.map((point, index) => <circle key={`${point.date}-${index}`} cx={point.x} cy={point.y} r="5" className="confidence-point" />)}</svg></div><div className="confidence-chart-dates">{points.map((point, index) => <span key={`${point.date}-${index}`}>{readableDate(point.date.slice(0, 10), { month: "short", day: "numeric" })}</span>)}</div></> : <InlineEmpty icon="trend" title="Confidence trend starts with a quiz" body="Rate each answer honestly to build a real confidence timeline." />}
          <div className="confidence-distribution"><span className="section-kicker">ALL RECORDED ANSWERS</span><div className="confidence-stacked-bar" aria-label={`${confidenceCounts.Low} low, ${confidenceCounts.Medium} medium, ${confidenceCounts.High} high confidence answers`}>{attempts.length ? <><span className="confidence-stack-low" style={{ width: `${(confidenceCounts.Low / attempts.length) * 100}%` }} /><span className="confidence-stack-medium" style={{ width: `${(confidenceCounts.Medium / attempts.length) * 100}%` }} /><span className="confidence-stack-high" style={{ width: `${(confidenceCounts.High / attempts.length) * 100}%` }} /></> : null}</div><div className="confidence-counts"><span><i className="confidence-dot confidence-dot--low" />Low <b>{confidenceCounts.Low}</b></span><span><i className="confidence-dot confidence-dot--medium" />Medium <b>{confidenceCounts.Medium}</b></span><span><i className="confidence-dot confidence-dot--high" />High <b>{confidenceCounts.High}</b></span></div></div>
        </section>
      </div>

      <section className="panel prepost-panel"><div className="panel-heading"><div><span className="section-kicker">FIRST QUIZ VS MOST RECENT</span><h2>Pre-test / post-test view</h2></div><span className="panel-heading-icon panel-heading-icon--violet"><Icon name="trend" size={18} /></span></div><p className="panel-intro">Topic scores are computed per saved quiz run. With one run, baseline and latest are the same; improvement is only visible after another quiz.</p>
        {attempts.length ? <div className="prepost-table-wrap"><table className="prepost-table"><thead><tr><th>Topic</th><th>Baseline quiz</th><th>Most recent</th><th>Change</th><th>Runs</th></tr></thead><tbody>{data.topics.map((topic) => { const topicRuns = [...(perTopicAssessments.get(topic.name)?.entries() ?? [])].map(([id, values]) => ({ id, ...values })).sort((a, b) => a.date.localeCompare(b.date)); if (!topicRuns.length) return <tr key={topic.id}><td><strong>{topic.name}</strong></td><td colSpan={4}><span className="table-not-assessed">Not assessed yet</span></td></tr>; const first = topicRuns[0]; const latest = topicRuns[topicRuns.length - 1]; const firstScore = Math.round((first.correct / first.total) * 100); const latestScore = Math.round((latest.correct / latest.total) * 100); const change = latestScore - firstScore; return <tr key={topic.id}><td><strong>{topic.name}</strong></td><td><span className="table-score">{firstScore}%</span><small>{readableDate(first.date.slice(0, 10))}</small></td><td><span className="table-score">{latestScore}%</span><small>{readableDate(latest.date.slice(0, 10))}</small></td><td><span className={`change-pill ${change > 0 ? "change-pill--up" : change < 0 ? "change-pill--down" : ""}`}>{change > 0 ? "+" : ""}{change} pp</span></td><td>{topicRuns.length}</td></tr>; })}</tbody></table></div> : <InlineEmpty icon="chart" title="Your baseline is waiting" body="Complete a quiz to record a first score. Take another later to compare real pre- and post-test results." action={<button className="button button--primary button--small" onClick={() => window.dispatchEvent(new CustomEvent("reviseright:openquiz"))}>Start a quiz</button>} />}
      </section>
      <div className="analytics-footnote"><Icon name="info" size={15} /><p><strong>How to read this page:</strong> syllabus coverage means a topic has at least one saved answer; accuracy is correct answers ÷ checked answers; a completed session is one you marked done. These descriptive metrics do not claim model accuracy or predict exam results.</p></div>
    </>
  );
}

export default function ReviseRightApp() {
  const [page, setPage] = useState<PageId>("dashboard");
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [data, setData] = useState<AppData | null>(null);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState("");
  const [busy, setBusy] = useState("");
  const [toast, setToast] = useState("");
  const [globalError, setGlobalError] = useState("");

  const [quizMode, setQuizMode] = useState<"idle" | "loading" | "active" | "finished">("idle");
  const [quizTopic, setQuizTopic] = useState("all");
  const [quizQuestions, setQuizQuestions] = useState<PublicQuestion[]>([]);
  const [quizIndex, setQuizIndex] = useState(0);
  const [quizSelected, setQuizSelected] = useState<number | null>(null);
  const [quizConfidence, setQuizConfidence] = useState<Confidence | null>(null);
  const [quizFeedback, setQuizFeedback] = useState<QuizFeedback[]>([]);
  const [currentFeedback, setCurrentFeedback] = useState<QuizFeedback | null>(null);
  const [quizAssessmentId, setQuizAssessmentId] = useState("");
  const [quizError, setQuizError] = useState("");
  const [quizSaving, setQuizSaving] = useState(false);

  const refreshData = useCallback(async () => {
    setLoadError("");
    try {
      const response = await requestJson<AppData>("/api/data");
      setData(response);
    } catch (error) {
      // Frontend preview mode: show sample data if PostgreSQL is not configured yet.
      // API-backed actions will become available after the database is connected.
      const today = new Date();
      const exam = new Date(today);
      exam.setDate(exam.getDate() + 30);
      const isoDate = (date: Date) => date.toISOString().slice(0, 10);
      setData({
        student: {
          id: 1,
          name: "Student",
          subject: "Operating Systems",
          examDate: isoDate(exam),
          dailyStudyHours: 2,
          studyPreference: "balanced",
        },
        topics: [
          { id: 1, studentId: 1, name: "Processes", description: "Process lifecycle, process control blocks, and context switches.", difficulty: "Medium", prerequisites: [], position: 1 },
          { id: 2, studentId: 1, name: "CPU Scheduling", description: "FCFS, SJF, priority scheduling, Round Robin, and scheduling calculations.", difficulty: "Hard", prerequisites: ["Processes"], position: 2 },
          { id: 3, studentId: 1, name: "Deadlocks", description: "Deadlock conditions, prevention, avoidance, detection, and recovery.", difficulty: "Hard", prerequisites: ["Processes"], position: 3 },
          { id: 4, studentId: 1, name: "Memory Management", description: "Address spaces, allocation, fragmentation, and virtual memory.", difficulty: "Medium", prerequisites: ["Processes"], position: 4 },
          { id: 5, studentId: 1, name: "Paging", description: "Pages, frames, page tables, TLBs, and page faults.", difficulty: "Hard", prerequisites: ["Memory Management"], position: 5 },
        ],
        attempts: [],
        sessions: [],
      });
      setLoadError("");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { void refreshData(); }, [refreshData]);

  const showToast = useCallback((message: string) => {
    setToast(message);
    window.setTimeout(() => setToast(""), 3200);
  }, []);

  const navigate = useCallback((destination: PageId) => {
    setPage(destination);
    setSidebarOpen(false);
    setGlobalError("");
  }, []);

  const handleStartQuiz = useCallback(async (topic?: string) => {
    const selectedTopic = topic ?? quizTopic;
    setPage("quiz");
    setSidebarOpen(false);
    setQuizTopic(selectedTopic);
    setQuizError("");
    setQuizMode("loading");
    setQuizQuestions([]);
    setQuizFeedback([]);
    setCurrentFeedback(null);
    setQuizIndex(0);
    setQuizSelected(null);
    setQuizConfidence(null);
    try {
      const response = await requestJson<{ questions: PublicQuestion[]; message: string | null }>(`/api/questions?topic=${encodeURIComponent(selectedTopic)}`);
      if (response.questions.length === 0) {
        setQuizError(response.message ?? "No questions are available for that topic yet.");
        setQuizMode("idle");
        return;
      }
      setQuizQuestions(response.questions);
      setQuizAssessmentId(`${Date.now()}-${Math.random().toString(36).slice(2, 10)}`);
      setQuizMode("active");
    } catch (error) {
      setQuizError(error instanceof Error ? error.message : "Questions could not be loaded.");
      setQuizMode("idle");
    }
  }, [quizTopic]);

  const handleCheckAnswer = useCallback(async () => {
    const question = quizQuestions[quizIndex];
    if (!question || quizSelected === null || !quizConfidence || !quizAssessmentId) return;
    setQuizSaving(true);
    setQuizError("");
    try {
      const response = await requestJson<{ correct: boolean; correctIndex: number; explanation: string }>("/api/attempts", {
        method: "POST",
        body: JSON.stringify({ questionId: question.id, answerIndex: quizSelected, confidence: quizConfidence, assessmentId: quizAssessmentId }),
      });
      const result: QuizFeedback = {
        questionId: question.id,
        topicName: question.topicName,
        prompt: question.prompt,
        options: question.options,
        selectedIndex: quizSelected,
        correctIndex: response.correctIndex,
        correct: response.correct,
        confidence: quizConfidence,
        explanation: response.explanation,
      };
      setCurrentFeedback(result);
      setQuizFeedback((previous) => [...previous, result]);
    } catch (error) {
      setQuizError(error instanceof Error ? error.message : "The answer could not be checked.");
    } finally {
      setQuizSaving(false);
    }
  }, [quizAssessmentId, quizConfidence, quizIndex, quizQuestions, quizSelected]);

  const handleContinueQuiz = useCallback(async () => {
    if (quizIndex >= quizQuestions.length - 1) {
      setQuizMode("finished");
      await refreshData();
      showToast("Quiz answers saved to your progress.");
      return;
    }
    setQuizIndex((index) => index + 1);
    setQuizSelected(null);
    setQuizConfidence(null);
    setCurrentFeedback(null);
    setQuizError("");
  }, [quizIndex, quizQuestions.length, refreshData, showToast]);

  const performMutation = useCallback(async (key: string, url: string, method: string, body: unknown, success: string) => {
    setBusy(key);
    setGlobalError("");
    try {
      await requestJson(url, { method, body: JSON.stringify(body) });
      await refreshData();
      showToast(success);
    } catch (error) {
      setGlobalError(error instanceof Error ? error.message : "Your change could not be saved.");
    } finally {
      setBusy("");
    }
  }, [refreshData, showToast]);

  const markSession = useCallback(async (session: StudySession) => {
    const status = session.status === "completed" ? "planned" : "completed";
    await performMutation(`session-${session.id}`, "/api/sessions", "PATCH", { sessionId: session.id, status }, status === "completed" ? "Study session marked complete." : "Session moved back to planned.");
  }, [performMutation]);

  const saveProfile = useCallback(async (values: Record<string, unknown>) => {
    await performMutation("profile", "/api/setup", "PATCH", values, "Your study profile and plan are saved.");
  }, [performMutation]);

  const addTopic = useCallback(async (topic: Record<string, unknown>) => {
    await performMutation("add-topic", "/api/setup", "PATCH", { topic }, "Topic added to your syllabus.");
  }, [performMutation]);

  const updateDifficulty = useCallback(async (topicId: number, difficulty: string) => {
    await performMutation(`difficulty-${topicId}`, "/api/setup", "PATCH", { topicId, difficulty }, "Topic difficulty updated.");
  }, [performMutation]);

  const generatePlan = useCallback(async () => {
    await performMutation("plan", "/api/planner", "POST", { action: "generate" }, "Your study plan has been refreshed.");
  }, [performMutation]);

  const reschedulePlan = useCallback(async (hours: number) => {
    await performMutation("reschedule", "/api/planner", "POST", { action: "reschedule", hours }, "Unfinished sessions reorganized for your available time.");
  }, [performMutation]);

  const exportData = useCallback(() => {
    if (!data) return;
    const exportPayload = { exportedAt: new Date().toISOString(), application: "ReviseRight AI", profile: data.student, topics: data.topics, quizAttempts: data.attempts, studySessions: data.sessions };
    const blob = new Blob([JSON.stringify(exportPayload, null, 2)], { type: "application/json" });
    const href = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = href;
    anchor.download = `reviseright-progress-${todayIso()}.json`;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    URL.revokeObjectURL(href);
    showToast("Progress data exported as JSON.");
  }, [data, showToast]);

  useEffect(() => {
    const openQuiz = () => { void handleStartQuiz(); };
    window.addEventListener("reviseright:openquiz", openQuiz);
    return () => window.removeEventListener("reviseright:openquiz", openQuiz);
  }, [handleStartQuiz]);

  const activePageName = useMemo(() => pageNames[page], [page]);

  if (loading && !data) {
    return <div className="boot-screen"><div className="boot-logo">R</div><span className="section-kicker">REVISERIGHT AI</span><h1>Preparing your study space</h1><p>Connecting to your saved profile and timetable…</p><span className="boot-spinner" /></div>;
  }

  if (!data) {
    return <div className="boot-screen"><div className="boot-logo">R</div><span className="section-kicker">REVISION COACH</span><h1>Your workspace needs a connection.</h1><p>{loadError || "The profile could not be loaded."}</p><button className="button button--primary" onClick={() => { setLoading(true); void refreshData(); }}><Icon name="refresh" size={15} /> Try again</button><small>Check that PostgreSQL is available and the project schema has been applied.</small></div>;
  }

  return (
    <div className="app-shell">
      {sidebarOpen ? <button className="mobile-sidebar-backdrop" aria-label="Close navigation" onClick={() => setSidebarOpen(false)} /> : null}
      <aside className={`sidebar ${sidebarOpen ? "sidebar--open" : ""}`}>
        <button className="brand-lockup" onClick={() => navigate("dashboard")} aria-label="ReviseRight AI dashboard"><span className="brand-mark"><span>R</span><i /></span><span className="brand-wordmark">revise<span>right</span><small>AI REVISION COACH</small></span></button>
        <div className="sidebar-workspace"><span className="workspace-pulse" /><span>{data.student.subject}</span><Icon name="chevron" size={14} /></div>
        <nav className="sidebar-nav" aria-label="Main navigation">
          {navigation.map((group) => <div className="nav-section" key={group.section}><span className="nav-section-label">{group.section}</span>{group.items.map((item) => <button key={item.id} className={`nav-link ${page === item.id ? "nav-link--active" : ""}`} onClick={() => navigate(item.id)}><Icon name={item.icon} size={18} /><span>{item.label}</span>{item.id === "gaps" && data.attempts.length > 0 && data.topics.some((topic) => topicStats(topic.name, data.attempts).priority === "High") ? <i className="nav-alert-dot" /> : null}{page === item.id ? <span className="nav-active-indicator" /> : null}</button>)}</div>)}
        </nav>
        <div className="sidebar-spacer" />
        <section className="sidebar-encouragement"><span className="sidebar-encouragement-icon"><Icon name="sparkle" size={16} /></span><strong>One step at a time.</strong><p>Your coach uses your own answers to suggest what to practice next.</p><button onClick={() => navigate("gaps")}>See my next step <Icon name="arrow" size={13} /></button></section>
        <button className="sidebar-profile" onClick={() => navigate("syllabus")}><span className="profile-avatar">{(data.student.name.trim()[0] || "S").toUpperCase()}</span><span className="profile-label"><strong>{data.student.name}</strong><small>Student workspace</small></span><Icon name="chevron" size={15} /></button>
      </aside>

      <div className="main-column">
        <header className="topbar"><div className="topbar-left"><button className="mobile-menu-button" onClick={() => setSidebarOpen(true)} aria-label="Open navigation"><Icon name="menu" size={20} /></button><span className="breadcrumb-root">MY WORKSPACE</span><Icon name="chevron" size={13} className="breadcrumb-chevron" /><span className="breadcrumb-current">{activePageName}</span></div><div className="topbar-right"><span className="connection-state"><i /> Data synced</span><span className="topbar-divider" /><span className="topbar-subject"><span className="subject-avatar">{(data.student.subject[0] || "O").toUpperCase()}</span>{data.student.subject}</span><button className="topbar-user" onClick={() => navigate("syllabus")} aria-label="Open student setup">{(data.student.name.trim()[0] || "S").toUpperCase()}</button></div></header>
        <main className="page-content">
          {globalError ? <div className="global-error-banner"><Icon name="alert" size={17} /><span>{globalError}</span><button onClick={() => setGlobalError("")} aria-label="Dismiss error"><Icon name="close" size={15} /></button></div> : null}
          {page === "dashboard" ? <DashboardPage data={data} onNavigate={navigate} onStartQuiz={handleStartQuiz} onComplete={markSession} busy={busy} /> : null}
          {page === "syllabus" ? <SyllabusPage data={data} busy={busy} onSaveProfile={saveProfile} onAddTopic={addTopic} onDifficulty={updateDifficulty} onStartQuiz={handleStartQuiz} /> : null}
          {page === "quiz" ? <QuizPage mode={quizMode} topic={quizTopic} questions={quizQuestions} index={quizIndex} selected={quizSelected} confidence={quizConfidence} feedback={quizFeedback} currentFeedback={currentFeedback} loading={quizMode === "loading"} saving={quizSaving} error={quizError} setTopic={setQuizTopic} setSelected={setQuizSelected} setConfidence={setQuizConfidence} onStart={() => { void handleStartQuiz(); }} onCheck={() => { void handleCheckAnswer(); }} onContinue={() => { void handleContinueQuiz(); }} /> : null}
          {page === "gaps" ? <LearningGapsPage data={data} onStartQuiz={handleStartQuiz} /> : null}
          {page === "planner" ? <PlannerPage data={data} busy={busy} onComplete={markSession} onGenerate={generatePlan} onReschedule={reschedulePlan} /> : null}
          {page === "resources" ? <ResourcesPage data={data} onStartQuiz={handleStartQuiz} /> : null}
          {page === "map" ? <LearningMapPage data={data} onStartQuiz={handleStartQuiz} /> : null}
          {page === "analytics" ? <AnalyticsPage data={data} onExport={exportData} /> : null}
          <footer className="page-footer"><span>ReviseRight AI <i>·</i> Your personal revision coach</span><span>Rule-based guidance · Built for learning, not prediction</span></footer>
        </main>
      </div>
      {toast ? <div className="toast-message" role="status"><span><Icon name="check" size={15} /></span>{toast}</div> : null}
    </div>
  );
}
